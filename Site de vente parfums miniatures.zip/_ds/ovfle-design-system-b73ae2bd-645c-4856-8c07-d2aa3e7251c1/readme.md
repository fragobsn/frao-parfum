# OVFLE Design System

OVFLE (also sold as "OVFLE Zonix") is a Pakistan-based wearables brand. Its flagship is the **WP-1 screenless fitness band**: no display, 24/7 heart rate, SpO₂, sleep and activity tracking, ~25 g, 125 mAh battery (7–10 days), data synced to a phone app. Sold direct at **ovfle.pk** (Rs 12,499, free nationwide shipping, cash on delivery) and through resellers in Pakistan, India and KSA. Eight strap colorways: Black, Beige, Dark Blue, Dark Green, Deep Teal, Light Gray, Light Green, Clear.

## Sources
- Only input: the company name "ovfle". No codebase, Figma, logo, fonts or decks were provided.
- Public research (Nov 2026): https://ovfle.pk/ and https://ovfle.pk/product/ovfle-wp-1-active (meta only — the site renders client-side), reseller listings (wearteck.pk, mrgadgetofficial.pk, urbanstoreindia.com), YouTube reviews.
- og:image referenced: https://ovfle.pk/assets/images/ovfle-wp-1-black.jpg (hotlinked, not copied).
- **Everything visual here is a proposed direction** derived from the product positioning (minimal, distraction-free, black-band hardware). Replace tokens with real brand values when available.

## Products / surfaces
1. **ovfle.pk storefront** — single-product D2C shop → `ui_kits/storefront/`.
2. Companion app — third-party ("G Band" per reseller listings), not OVFLE-designed; no kit made.

## CONTENT FUNDAMENTALS
- **Voice:** calm, factual, confident. The product is about *less*; the copy is too. Lead with what it does, then the number.
- **Person:** second person ("your phone", "you'll forget you're wearing it"). Brand speaks as "we" only for service promises ("We'll confirm by phone").
- **Casing:** sentence case for headings, buttons and nav ("Add to cart", "Shop WP-1"). The product name is always **WP-1** (caps, hyphen); brand is **OVFLE** in caps. UPPERCASE only for mono eyebrows/badges.
- **Numbers are the hero:** "25 g", "7–10 days", "24/7", "8 colorways". Use an en dash for ranges, thin unit after the number, SpO₂ with subscript.
- **Local commerce cues** belong up front: "Free nationwide shipping", "Cash on delivery across Pakistan", prices as "Rs 12,499" (en-PK grouping).
- **Short sentences, paired negatives:** "No screen. No distractions." "Everything a smartwatch measures. Nothing it shows you."
- **No emoji, no hype** ("ultimate", "killer", 🔥). Reseller/YouTube copy uses those — the brand should not.

## VISUAL FOUNDATIONS
- **Color:** a near-monochrome system — *ink* (from the black band, `--ink-900 #161714`) on warm *paper* off-whites (`--paper-0 #FAF9F5`). One accent, **Deep Teal** (`--teal-700`, also a real colorway) for links, checkout and icon tints. **Pulse lime** (`--pulse-400`) is a signal color: live data, the "on" switch knob, count bubbles, hover on dark — never large fills on light. Colorway tokens `--band-*` are used only to depict straps.
- **Type:** Archivo (variable) — display set at 112% width, 700–800 weight, −0.035em tracking, line-height .94; body at 100% width 400/600, 1.55 leading. IBM Plex Mono for eyebrows, units, SKUs, badges (uppercase, +0.1em). Big numbers use display type + small mono unit.
- **Spacing:** 4-based scale (2,4,8,12,16,24,32,48,64,96,128). Sections breathe at 96px; container 1240 with 32 gutters. Controls 36/44/56.
- **Backgrounds:** flat paper or flat ink. No gradients, patterns or textures. Full-width ink bands break up long pages (metric strip, footer). Product photos sit on flat tinted grounds matching the strap color.
- **Imagery:** clean studio product shots, neutral/warm light, soft shadows, no grain. Lifestyle shots (if added) should be muted and natural.
- **Corners:** pill (999) for buttons, tags, steppers, swatches — echoes the strap. 22–32px on cards and media, 8px on inputs, 4px on checkboxes.
- **Cards:** white or paper-50 fill, 1px `--border-1` hairline, **no resting shadow**. Interactive cards lift 2px with `--shadow-2` on hover.
- **Borders:** 1px hairlines (ink-100/200) for structure; 1.5px ink for emphasis/selection (outline button, selected swatch ring, radio).
- **Shadows:** three steps, all soft and low-opacity; used only for lift and overlays (drawer, dialog, toast).
- **Transparency & blur:** only the sticky header (78% paper + 14px blur) and modal scrims (ink 42% + 4px blur).
- **Motion:** ease-out `cubic-bezier(.2,.7,.2,1)`, 120/200/360ms. Fades, slides and small translations; no bounce or spring. Drawers slide 360ms; accordions animate grid rows.
- **Hover:** fills darken (ink-900→700, teal-700→900); outline/ghost fill to ink or ink-100; inverse buttons turn Pulse lime. Links underline offset 3px, darken to teal-900.
- **Press:** scale(.98) on buttons. **Focus:** ink border + 3px teal ring (`--shadow-focus`).
- **Layout:** sticky header 68px with announcement bar above; generous two-column splits (copy | media); max one primary action per view.

## ICONOGRAPHY
- **Lucide** line icons via CDN (`https://unpkg.com/lucide@0.460.0/dist/umd/lucide.min.js`), 1.75 stroke, round caps/joins, 16/20/24/28 sizes. Wrapped by the `Icon` component (kebab-case names).
- **Substitution flag:** OVFLE's own icon set (if any) was not available; Lucide was chosen for its neutral geometric line style.
- Icons are tinted ink by default, teal for feature/trust icons on light, Pulse lime on ink.
- No emoji. Unicode only for typographic needs (–, ×, ₂, ·).
- **Logo:** none provided. The brand name is set in Archivo 800 / 112% wherever a mark would go. Do not draw a logo.

## Fonts (substitution flag)
Archivo + IBM Plex Mono are **Google Fonts substitutes**, self-hosted in `assets/fonts/`. Supply the real brand fonts to replace them in `tokens/fonts.css`.

## Index
- `styles.css` — entry point (imports only) → `tokens/` fonts, colors, typography, spacing, effects, base
- `assets/fonts/` — woff2 files
- `guidelines/` — foundation specimen cards (Colors, Type, Spacing, Brand)
- `components/` — React primitives, each with `.jsx`, `.d.ts`, `.prompt.md` and one card per folder
- `ui_kits/storefront/` — ovfle.pk click-through
- `thumbnail.html`, `SKILL.md`

## Components
- **core:** Icon, Button, IconButton, Badge, Tag, Card, Tooltip
- **forms:** Input, Select, Checkbox, Radio, Switch, QuantityStepper, ColorSwatchPicker (+ `OVFLE_COLORWAYS` data)
- **navigation:** Tabs, Accordion
- **feedback:** Dialog, Toast
- **commerce:** MetricStat, ProductMedia, PriceTag

No source inventory existed, so this is a standard set sized for a single-product shop. Intentional additions beyond the standard list: QuantityStepper, ColorSwatchPicker, Accordion (FAQ), MetricStat, ProductMedia, PriceTag. All are commerce/spec needs of the storefront.
