/* @ds-bundle: {"format":4,"namespace":"OVFLEDesignSystem_b73ae2","components":[{"name":"MetricStat","sourcePath":"components/commerce/MetricStat.jsx"},{"name":"PriceTag","sourcePath":"components/commerce/PriceTag.jsx"},{"name":"ProductMedia","sourcePath":"components/commerce/ProductMedia.jsx"},{"name":"Badge","sourcePath":"components/core/Badge.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Card","sourcePath":"components/core/Card.jsx"},{"name":"Icon","sourcePath":"components/core/Icon.jsx"},{"name":"IconButton","sourcePath":"components/core/IconButton.jsx"},{"name":"Tag","sourcePath":"components/core/Tag.jsx"},{"name":"Tooltip","sourcePath":"components/core/Tooltip.jsx"},{"name":"Dialog","sourcePath":"components/feedback/Dialog.jsx"},{"name":"Toast","sourcePath":"components/feedback/Toast.jsx"},{"name":"Checkbox","sourcePath":"components/forms/Checkbox.jsx"},{"name":"OVFLE_COLORWAYS","sourcePath":"components/forms/ColorSwatchPicker.jsx"},{"name":"ColorSwatchPicker","sourcePath":"components/forms/ColorSwatchPicker.jsx"},{"name":"Input","sourcePath":"components/forms/Input.jsx"},{"name":"QuantityStepper","sourcePath":"components/forms/QuantityStepper.jsx"},{"name":"Radio","sourcePath":"components/forms/Radio.jsx"},{"name":"Select","sourcePath":"components/forms/Select.jsx"},{"name":"Switch","sourcePath":"components/forms/Switch.jsx"},{"name":"Accordion","sourcePath":"components/navigation/Accordion.jsx"},{"name":"Tabs","sourcePath":"components/navigation/Tabs.jsx"}],"sourceHashes":{"components/commerce/MetricStat.jsx":"8a0d171e05c0","components/commerce/PriceTag.jsx":"8f6e84b1d455","components/commerce/ProductMedia.jsx":"d58d6a38df55","components/core/Badge.jsx":"c003f6e3d93e","components/core/Button.jsx":"e48c5241f7a4","components/core/Card.jsx":"fed06a41f65d","components/core/Icon.jsx":"5da08c4a08b1","components/core/IconButton.jsx":"333e9ae58313","components/core/Tag.jsx":"04f15e441ef3","components/core/Tooltip.jsx":"887c2aab6abd","components/feedback/Dialog.jsx":"d3026cc68294","components/feedback/Toast.jsx":"9d4bc8c2eab9","components/forms/Checkbox.jsx":"306c7f2bbc97","components/forms/ColorSwatchPicker.jsx":"e994eaf8c7e4","components/forms/Input.jsx":"d3bb9dd54def","components/forms/QuantityStepper.jsx":"b34faec249b3","components/forms/Radio.jsx":"117019bff965","components/forms/Select.jsx":"1212dd0c48ac","components/forms/Switch.jsx":"3fc8bb4e1216","components/navigation/Accordion.jsx":"2fd77ffa530e","components/navigation/Tabs.jsx":"59f0690e5730","site/Accessories.jsx":"51e7e65220b4","site/Cart.jsx":"6eb0c95ca01e","site/Checkout.jsx":"c42517568c3d","site/Colors.jsx":"e7e37aaaa5cc","site/Home.jsx":"cdceab036fc0","site/HowItWorks.jsx":"1367e5a33d9e","site/Layout.jsx":"01decd632e48","site/Product.jsx":"e66d5b55eba5","site/data.js":"918d5cd1627e","ui_kits/storefront/CartDrawer.jsx":"e419d91f4fb1","ui_kits/storefront/CheckoutScreen.jsx":"4387f690a2e6","ui_kits/storefront/Chrome.jsx":"e5108120f526","ui_kits/storefront/HomeScreen.jsx":"7acc4b48e6ed","ui_kits/storefront/ProductScreen.jsx":"967c5e5f9cfb","ui_kits/storefront/data.js":"416fe7d20f4f"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.OVFLEDesignSystem_b73ae2 = window.OVFLEDesignSystem_b73ae2 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/commerce/PriceTag.jsx
try { (() => {
const fmt = n => typeof n === "number" ? n.toLocaleString("en-PK") : n;
function PriceTag({
  price,
  compareAt,
  currency = "Rs",
  format,
  size = "md",
  style
}) {
  const show = v => format ? format(v) : `${currency} ${fmt(v)}`;
  const fs = {
    sm: 16,
    md: 22,
    lg: 32
  }[size] || 22;
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "baseline",
      gap: 10,
      ...style
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-display)",
      fontStretch: "112%",
      fontWeight: 700,
      fontSize: fs,
      letterSpacing: "-.02em",
      fontVariantNumeric: "tabular-nums"
    }
  }, show(price)), compareAt && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: Math.round(fs * .62),
      color: "var(--fg-3)",
      textDecoration: "line-through"
    }
  }, show(compareAt)));
}
Object.assign(__ds_scope, { PriceTag });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/commerce/PriceTag.jsx", error: String((e && e.message) || e) }); }

// components/commerce/ProductMedia.jsx
try { (() => {
function ProductMedia({
  src,
  alt = "",
  tone = "var(--paper-50)",
  label,
  ratio = "1 / 1",
  radius = "lg",
  style
}) {
  const [err, setErr] = React.useState(false);
  const show = src && !err;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      aspectRatio: ratio,
      borderRadius: `var(--radius-${radius})`,
      overflow: "hidden",
      background: tone,
      ...style
    }
  }, show && /*#__PURE__*/React.createElement("img", {
    src: src,
    alt: alt,
    onError: () => setErr(true),
    style: {
      position: "absolute",
      inset: 0,
      width: "100%",
      height: "100%",
      objectFit: "cover"
    }
  }), !show && /*#__PURE__*/React.createElement("span", {
    style: {
      position: "absolute",
      left: 16,
      bottom: 14,
      fontFamily: "var(--font-mono)",
      fontSize: 11,
      letterSpacing: ".1em",
      textTransform: "uppercase",
      color: "rgba(22,23,20,.55)",
      mixBlendMode: "multiply"
    }
  }, label || alt || "Product photo"));
}
Object.assign(__ds_scope, { ProductMedia });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/commerce/ProductMedia.jsx", error: String((e && e.message) || e) }); }

// components/core/Badge.jsx
try { (() => {
const T = {
  neutral: ["var(--ink-100)", "var(--ink-800)"],
  ink: ["var(--ink-900)", "var(--paper-0)"],
  pulse: ["var(--pulse-400)", "var(--ink-900)"],
  teal: ["var(--teal-100)", "var(--teal-900)"],
  success: ["var(--success-100)", "var(--success-600)"],
  warning: ["var(--warning-100)", "var(--warning-600)"],
  danger: ["var(--danger-100)", "var(--danger-600)"]
};
function Badge({
  children,
  tone = "neutral",
  dot = false,
  style
}) {
  const [bg, fg] = T[tone] || T.neutral;
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 6,
      height: 22,
      padding: "0 9px",
      borderRadius: "var(--radius-pill)",
      background: bg,
      color: fg,
      fontFamily: "var(--font-mono)",
      fontSize: 11,
      fontWeight: 500,
      letterSpacing: ".08em",
      textTransform: "uppercase",
      lineHeight: 1,
      whiteSpace: "nowrap",
      ...style
    }
  }, dot && /*#__PURE__*/React.createElement("span", {
    style: {
      width: 6,
      height: 6,
      borderRadius: 999,
      background: "currentColor"
    }
  }), children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Badge.jsx", error: String((e && e.message) || e) }); }

// components/core/Card.jsx
try { (() => {
const V = {
  plain: {
    background: "var(--surface-card)",
    border: "1px solid var(--border-1)"
  },
  sunken: {
    background: "var(--surface-sunken)",
    border: "1px solid transparent"
  },
  inverse: {
    background: "var(--surface-inverse)",
    border: "1px solid transparent",
    color: "var(--fg-inverse)"
  },
  outline: {
    background: "transparent",
    border: "1px solid var(--border-2)"
  }
};
function Card({
  children,
  variant = "plain",
  padding = 24,
  radius = "lg",
  interactive = false,
  onClick,
  style
}) {
  const [h, setH] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", {
    onClick: onClick,
    onMouseEnter: () => setH(true),
    onMouseLeave: () => setH(false),
    style: {
      ...(V[variant] || V.plain),
      borderRadius: `var(--radius-${radius})`,
      padding,
      boxSizing: "border-box",
      boxShadow: interactive && h ? "var(--shadow-2)" : "none",
      transform: interactive && h ? "translateY(-2px)" : "none",
      cursor: interactive ? "pointer" : undefined,
      transition: "box-shadow var(--dur-slow) var(--ease-out),transform var(--dur-slow) var(--ease-out)",
      ...style
    }
  }, children);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Card.jsx", error: String((e && e.message) || e) }); }

// components/core/Icon.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const toPascal = s => s.split(/[-_ ]/).map(p => p.charAt(0).toUpperCase() + p.slice(1)).join("");
function Icon({
  name,
  size = 20,
  strokeWidth = 1.75,
  color = "currentColor",
  style,
  ...rest
}) {
  const lib = typeof window !== "undefined" && window.lucide && window.lucide.icons;
  let node = lib ? lib[toPascal(name)] : null;
  if (node && node[0] === "svg") node = node[2];
  const kids = (node || []).map(([tag, attrs], i) => React.createElement(tag, {
    key: i,
    ...attrs
  }));
  return /*#__PURE__*/React.createElement("svg", _extends({
    xmlns: "http://www.w3.org/2000/svg",
    width: size,
    height: size,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: color,
    strokeWidth: strokeWidth,
    strokeLinecap: "round",
    strokeLinejoin: "round",
    "aria-hidden": "true",
    style: {
      flex: "none",
      display: "block",
      ...style
    }
  }, rest), kids);
}
Object.assign(__ds_scope, { Icon });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Icon.jsx", error: String((e && e.message) || e) }); }

// components/commerce/MetricStat.jsx
try { (() => {
function MetricStat({
  value,
  unit,
  label,
  icon,
  size = "md",
  inverse = false,
  style
}) {
  const big = size === "lg";
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: big ? 10 : 6,
      color: inverse ? "var(--fg-inverse)" : "var(--fg-1)",
      ...style
    }
  }, (icon || label) && /*#__PURE__*/React.createElement("span", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 8,
      fontFamily: "var(--font-mono)",
      fontSize: 12,
      letterSpacing: ".1em",
      textTransform: "uppercase",
      color: inverse ? "var(--fg-inverse-2)" : "var(--fg-2)"
    }
  }, icon && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: 16,
    color: inverse ? "var(--pulse-400)" : "var(--accent)"
  }), label), /*#__PURE__*/React.createElement("span", {
    style: {
      display: "flex",
      alignItems: "baseline",
      gap: 6
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-display)",
      fontStretch: "112%",
      fontWeight: 700,
      fontSize: big ? "var(--fs-metric-xl)" : "var(--fs-metric)",
      letterSpacing: "-.04em",
      lineHeight: .95,
      fontVariantNumeric: "tabular-nums"
    }
  }, value), unit && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: big ? 16 : 14,
      color: inverse ? "var(--fg-inverse-2)" : "var(--fg-2)"
    }
  }, unit)));
}
Object.assign(__ds_scope, { MetricStat });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/commerce/MetricStat.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
const SIZES = {
  sm: {
    h: "var(--control-h-sm)",
    px: 16,
    fs: 14,
    ic: 16
  },
  md: {
    h: "var(--control-h-md)",
    px: 22,
    fs: 15,
    ic: 18
  },
  lg: {
    h: "var(--control-h-lg)",
    px: 30,
    fs: 16,
    ic: 20
  }
};
const V = {
  primary: {
    bg: "var(--ink-900)",
    fg: "var(--paper-0)",
    bd: "var(--ink-900)",
    hbg: "var(--ink-700)",
    hfg: "var(--paper-0)",
    hbd: "var(--ink-700)"
  },
  accent: {
    bg: "var(--accent)",
    fg: "var(--accent-fg)",
    bd: "var(--accent)",
    hbg: "var(--accent-hover)",
    hfg: "var(--accent-fg)",
    hbd: "var(--accent-hover)"
  },
  secondary: {
    bg: "transparent",
    fg: "var(--ink-900)",
    bd: "var(--ink-900)",
    hbg: "var(--ink-900)",
    hfg: "var(--paper-0)",
    hbd: "var(--ink-900)"
  },
  ghost: {
    bg: "transparent",
    fg: "var(--ink-900)",
    bd: "transparent",
    hbg: "var(--ink-100)",
    hfg: "var(--ink-900)",
    hbd: "transparent"
  },
  inverse: {
    bg: "var(--paper-0)",
    fg: "var(--ink-900)",
    bd: "var(--paper-0)",
    hbg: "var(--pulse-400)",
    hfg: "var(--ink-900)",
    hbd: "var(--pulse-400)"
  }
};
function Button({
  children,
  variant = "primary",
  size = "md",
  iconLeft,
  iconRight,
  fullWidth = false,
  disabled = false,
  type = "button",
  onClick,
  style
}) {
  const [h, setH] = React.useState(false);
  const [p, setP] = React.useState(false);
  const s = SIZES[size] || SIZES.md;
  const v = V[variant] || V.primary;
  const on = h && !disabled;
  return /*#__PURE__*/React.createElement("button", {
    type: type,
    disabled: disabled,
    onClick: onClick,
    onMouseEnter: () => setH(true),
    onMouseLeave: () => {
      setH(false);
      setP(false);
    },
    onMouseDown: () => setP(true),
    onMouseUp: () => setP(false),
    style: {
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      gap: 8,
      height: s.h,
      padding: `0 ${s.px}px`,
      width: fullWidth ? "100%" : undefined,
      fontFamily: "var(--font-body)",
      fontSize: s.fs,
      fontWeight: 600,
      letterSpacing: "-.005em",
      lineHeight: 1,
      whiteSpace: "nowrap",
      background: on ? v.hbg : v.bg,
      color: on ? v.hfg : v.fg,
      border: `var(--border-w-strong) solid ${on ? v.hbd : v.bd}`,
      borderRadius: "var(--radius-pill)",
      cursor: disabled ? "not-allowed" : "pointer",
      opacity: disabled ? .4 : 1,
      transform: p && !disabled ? "scale(.98)" : "none",
      transition: "background var(--dur-base) var(--ease-out),color var(--dur-base) var(--ease-out),border-color var(--dur-base) var(--ease-out),transform var(--dur-fast) var(--ease-out)",
      ...style
    }
  }, iconLeft && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: iconLeft,
    size: s.ic
  }), children, iconRight && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: iconRight,
    size: s.ic
  }));
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/IconButton.jsx
try { (() => {
const S = {
  sm: [36, 16],
  md: [44, 20],
  lg: [56, 22]
};
function IconButton({
  icon,
  label,
  variant = "ghost",
  size = "md",
  badge,
  onClick,
  disabled = false,
  style
}) {
  const [h, setH] = React.useState(false);
  const [d, ic] = S[size] || S.md;
  const map = {
    ghost: [h ? "var(--ink-100)" : "transparent", "var(--ink-900)", "transparent"],
    outline: [h ? "var(--ink-900)" : "transparent", h ? "var(--paper-0)" : "var(--ink-900)", "var(--border-2)"],
    solid: [h ? "var(--ink-700)" : "var(--ink-900)", "var(--paper-0)", "transparent"],
    inverse: [h ? "var(--ink-700)" : "transparent", "var(--paper-0)", "var(--border-inverse)"]
  };
  const [bg, fg, bd] = map[variant] || map.ghost;
  return /*#__PURE__*/React.createElement("button", {
    type: "button",
    "aria-label": label,
    title: label,
    onClick: onClick,
    disabled: disabled,
    onMouseEnter: () => setH(true),
    onMouseLeave: () => setH(false),
    style: {
      position: "relative",
      width: d,
      height: d,
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      borderRadius: "var(--radius-pill)",
      background: bg,
      color: fg,
      border: `1px solid ${bd}`,
      cursor: disabled ? "not-allowed" : "pointer",
      opacity: disabled ? .4 : 1,
      padding: 0,
      transition: "background var(--dur-base) var(--ease-out),color var(--dur-base) var(--ease-out)",
      ...style
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: ic
  }), badge != null && /*#__PURE__*/React.createElement("span", {
    style: {
      position: "absolute",
      top: 2,
      right: 2,
      minWidth: 18,
      height: 18,
      padding: "0 5px",
      boxSizing: "border-box",
      borderRadius: 999,
      background: "var(--pulse-400)",
      color: "var(--ink-900)",
      fontFamily: "var(--font-mono)",
      fontSize: 11,
      fontWeight: 500,
      lineHeight: "18px",
      textAlign: "center"
    }
  }, badge));
}
Object.assign(__ds_scope, { IconButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/IconButton.jsx", error: String((e && e.message) || e) }); }

// components/core/Tag.jsx
try { (() => {
function Tag({
  children,
  icon,
  selected = false,
  onClick,
  onRemove,
  style
}) {
  const [h, setH] = React.useState(false);
  const click = !!onClick;
  return /*#__PURE__*/React.createElement("span", {
    onClick: onClick,
    onMouseEnter: () => setH(true),
    onMouseLeave: () => setH(false),
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 6,
      height: 32,
      padding: "0 14px",
      borderRadius: "var(--radius-pill)",
      border: `1px solid ${selected ? "var(--ink-900)" : "var(--border-2)"}`,
      background: selected ? "var(--ink-900)" : h && click ? "var(--ink-100)" : "transparent",
      color: selected ? "var(--paper-0)" : "var(--ink-900)",
      fontSize: 14,
      fontWeight: 500,
      cursor: click ? "pointer" : "default",
      transition: "background var(--dur-base) var(--ease-out)",
      ...style
    }
  }, icon && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: 16
  }), children, onRemove && /*#__PURE__*/React.createElement("span", {
    onClick: e => {
      e.stopPropagation();
      onRemove();
    },
    style: {
      display: "inline-flex",
      marginRight: -4,
      cursor: "pointer",
      opacity: .6
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "x",
    size: 14
  })));
}
Object.assign(__ds_scope, { Tag });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Tag.jsx", error: String((e && e.message) || e) }); }

// components/core/Tooltip.jsx
try { (() => {
function Tooltip({
  children,
  content,
  placement = "top"
}) {
  const [o, setO] = React.useState(false);
  const pos = placement === "bottom" ? {
    top: "calc(100% + 8px)"
  } : {
    bottom: "calc(100% + 8px)"
  };
  return /*#__PURE__*/React.createElement("span", {
    style: {
      position: "relative",
      display: "inline-flex"
    },
    onMouseEnter: () => setO(true),
    onMouseLeave: () => setO(false),
    onFocus: () => setO(true),
    onBlur: () => setO(false)
  }, children, /*#__PURE__*/React.createElement("span", {
    role: "tooltip",
    style: {
      position: "absolute",
      left: "50%",
      ...pos,
      transform: `translateX(-50%) translateY(${o ? 0 : placement === "bottom" ? -4 : 4}px)`,
      opacity: o ? 1 : 0,
      pointerEvents: "none",
      background: "var(--ink-900)",
      color: "var(--paper-0)",
      fontSize: 12,
      lineHeight: 1.35,
      padding: "7px 10px",
      borderRadius: "var(--radius-sm)",
      whiteSpace: "nowrap",
      zIndex: 20,
      transition: "opacity var(--dur-base) var(--ease-out),transform var(--dur-base) var(--ease-out)"
    }
  }, content));
}
Object.assign(__ds_scope, { Tooltip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Tooltip.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Dialog.jsx
try { (() => {
function Dialog({
  open,
  onClose,
  title,
  children,
  footer,
  width = 480,
  inline = false
}) {
  if (!open) return null;
  const panel = /*#__PURE__*/React.createElement("div", {
    role: "dialog",
    "aria-modal": "true",
    onClick: e => e.stopPropagation(),
    style: {
      width,
      maxWidth: "calc(100vw - 32px)",
      background: "var(--surface-raised)",
      borderRadius: "var(--radius-lg)",
      boxShadow: "var(--shadow-3)",
      padding: 28,
      boxSizing: "border-box",
      display: "flex",
      flexDirection: "column",
      gap: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "flex-start",
      gap: 16
    }
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      margin: 0,
      fontFamily: "var(--font-display)",
      fontStretch: "112%",
      fontSize: 24,
      fontWeight: 700,
      letterSpacing: "-.02em",
      lineHeight: 1.1
    }
  }, title), onClose && /*#__PURE__*/React.createElement(__ds_scope.IconButton, {
    icon: "x",
    label: "Close",
    size: "sm",
    onClick: onClose,
    style: {
      marginTop: -6,
      marginRight: -8
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 15,
      color: "var(--fg-2)",
      lineHeight: 1.55
    }
  }, children), footer && /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "flex-end",
      gap: 10,
      marginTop: 8
    }
  }, footer));
  if (inline) return panel;
  return /*#__PURE__*/React.createElement("div", {
    onClick: onClose,
    style: {
      position: "fixed",
      inset: 0,
      zIndex: 100,
      background: "rgba(14,15,13,.42)",
      backdropFilter: "blur(4px)",
      display: "flex",
      alignItems: "center",
      justifyContent: "center"
    }
  }, panel);
}
Object.assign(__ds_scope, { Dialog });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Dialog.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Toast.jsx
try { (() => {
const T = {
  neutral: "info",
  success: "check-circle-2",
  warning: "alert-triangle",
  danger: "x-circle"
};
function Toast({
  title,
  message,
  tone = "neutral",
  action,
  onAction,
  onClose,
  style
}) {
  const ic = {
    neutral: "var(--paper-0)",
    success: "var(--pulse-400)",
    warning: "#F2C46B",
    danger: "#F09A85"
  }[tone];
  return /*#__PURE__*/React.createElement("div", {
    role: "status",
    style: {
      display: "flex",
      alignItems: "flex-start",
      gap: 12,
      width: 360,
      maxWidth: "100%",
      boxSizing: "border-box",
      padding: "14px 16px",
      background: "var(--ink-900)",
      color: "var(--paper-0)",
      borderRadius: "var(--radius-md)",
      boxShadow: "var(--shadow-3)",
      ...style
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: T[tone] || T.neutral,
    size: 20,
    color: ic,
    style: {
      marginTop: 1
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      display: "flex",
      flexDirection: "column",
      gap: 2
    }
  }, title && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 15,
      fontWeight: 600
    }
  }, title), message && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 14,
      color: "var(--ink-300)",
      lineHeight: 1.45
    }
  }, message)), action && /*#__PURE__*/React.createElement("button", {
    onClick: onAction,
    style: {
      border: 0,
      background: "transparent",
      color: "var(--pulse-400)",
      font: "inherit",
      fontSize: 14,
      fontWeight: 600,
      cursor: "pointer",
      padding: 0,
      marginTop: 1
    }
  }, action), onClose && /*#__PURE__*/React.createElement("button", {
    onClick: onClose,
    "aria-label": "Dismiss",
    style: {
      border: 0,
      background: "transparent",
      color: "var(--ink-300)",
      cursor: "pointer",
      padding: 0,
      marginTop: 1
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "x",
    size: 16
  })));
}
Object.assign(__ds_scope, { Toast });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Toast.jsx", error: String((e && e.message) || e) }); }

// components/forms/Checkbox.jsx
try { (() => {
function Checkbox({
  label,
  checked,
  defaultChecked = false,
  onChange,
  disabled = false,
  style
}) {
  const [c, setC] = React.useState(defaultChecked);
  const on = checked != null ? checked : c;
  const t = () => {
    if (disabled) return;
    setC(!on);
    onChange && onChange(!on);
  };
  return /*#__PURE__*/React.createElement("label", {
    onClick: e => {
      e.preventDefault();
      t();
    },
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 10,
      cursor: disabled ? "not-allowed" : "pointer",
      opacity: disabled ? .45 : 1,
      fontSize: 15,
      ...style
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 20,
      height: 20,
      borderRadius: "var(--radius-xs)",
      border: `1.5px solid ${on ? "var(--ink-900)" : "var(--ink-300)"}`,
      background: on ? "var(--ink-900)" : "var(--white)",
      color: "var(--paper-0)",
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      transition: "all var(--dur-fast) var(--ease-out)"
    }
  }, on && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "check",
    size: 14,
    strokeWidth: 2.5
  })), label);
}
Object.assign(__ds_scope, { Checkbox });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Checkbox.jsx", error: String((e && e.message) || e) }); }

// components/forms/ColorSwatchPicker.jsx
try { (() => {
const OVFLE_COLORWAYS = [{
  id: "black",
  name: "Black",
  color: "var(--band-black)"
}, {
  id: "beige",
  name: "Beige",
  color: "var(--band-beige)"
}, {
  id: "dark-blue",
  name: "Dark Blue",
  color: "var(--band-dark-blue)"
}, {
  id: "dark-green",
  name: "Dark Green",
  color: "var(--band-dark-green)"
}, {
  id: "deep-teal",
  name: "Deep Teal",
  color: "var(--band-deep-teal)"
}, {
  id: "light-gray",
  name: "Light Gray",
  color: "var(--band-light-gray)"
}, {
  id: "light-green",
  name: "Light Green",
  color: "var(--band-light-green)"
}, {
  id: "clear",
  name: "Clear",
  color: "var(--band-clear)"
}];
function ColorSwatchPicker({
  options = OVFLE_COLORWAYS,
  value,
  defaultValue,
  onChange,
  size = 32,
  showLabel = true,
  style
}) {
  const [v, setV] = React.useState(defaultValue || options[0] && options[0].id);
  const cur = value != null ? value : v;
  const sel = options.find(o => o.id === cur);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 12,
      ...style
    }
  }, showLabel && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 14,
      color: "var(--fg-2)"
    }
  }, "Color \u2014 ", /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--fg-1)",
      fontWeight: 600
    }
  }, sel && sel.name)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexWrap: "wrap",
      gap: 10
    }
  }, options.map(o => {
    const on = o.id === cur;
    return /*#__PURE__*/React.createElement("button", {
      key: o.id,
      type: "button",
      "aria-label": o.name,
      title: o.name,
      onClick: () => {
        setV(o.id);
        onChange && onChange(o.id);
      },
      style: {
        width: size + 8,
        height: size + 8,
        padding: 3,
        borderRadius: 999,
        border: `1.5px solid ${on ? "var(--ink-900)" : "transparent"}`,
        background: "transparent",
        cursor: "pointer",
        transition: "border-color var(--dur-base) var(--ease-out)"
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        display: "block",
        width: "100%",
        height: "100%",
        borderRadius: 999,
        background: o.color,
        boxShadow: "inset 0 0 0 1px rgba(22,23,20,.12)",
        backgroundImage: o.id === "clear" ? "linear-gradient(135deg,rgba(255,255,255,.7),rgba(255,255,255,0) 60%)" : undefined
      }
    }));
  })));
}
Object.assign(__ds_scope, { OVFLE_COLORWAYS, ColorSwatchPicker });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/ColorSwatchPicker.jsx", error: String((e && e.message) || e) }); }

// components/forms/Input.jsx
try { (() => {
const Label = ({
  children
}) => /*#__PURE__*/React.createElement("span", {
  style: {
    fontSize: 13,
    fontWeight: 600,
    color: "var(--fg-1)"
  }
}, children);
const Help = ({
  children,
  error
}) => /*#__PURE__*/React.createElement("span", {
  style: {
    fontSize: 13,
    color: error ? "var(--danger-600)" : "var(--fg-2)"
  }
}, children);
function Input({
  label,
  placeholder,
  value,
  defaultValue,
  onChange,
  type = "text",
  icon,
  prefix,
  help,
  error,
  disabled = false,
  style
}) {
  const [fc, setFc] = React.useState(false);
  const bd = error ? "var(--danger-600)" : fc ? "var(--ink-900)" : "var(--border-2)";
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 6,
      ...style
    }
  }, label && /*#__PURE__*/React.createElement(Label, null, label), /*#__PURE__*/React.createElement("span", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 10,
      height: "var(--control-h-md)",
      padding: "0 14px",
      background: disabled ? "var(--bg-subtle)" : "var(--white)",
      border: `1px solid ${bd}`,
      borderRadius: "var(--radius-sm)",
      boxShadow: fc && !error ? "var(--shadow-focus)" : "none",
      transition: "border-color var(--dur-base) var(--ease-out),box-shadow var(--dur-base) var(--ease-out)"
    }
  }, icon && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: 18,
    color: "var(--fg-2)"
  }), prefix && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: 14,
      color: "var(--fg-2)"
    }
  }, prefix), /*#__PURE__*/React.createElement("input", {
    type: type,
    placeholder: placeholder,
    value: value,
    defaultValue: defaultValue,
    onChange: onChange,
    disabled: disabled,
    onFocus: () => setFc(true),
    onBlur: () => setFc(false),
    style: {
      flex: 1,
      minWidth: 0,
      border: 0,
      outline: 0,
      background: "transparent",
      font: "inherit",
      fontSize: 15,
      color: "var(--fg-1)"
    }
  })), (error || help) && /*#__PURE__*/React.createElement(Help, {
    error: !!error
  }, error || help));
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Input.jsx", error: String((e && e.message) || e) }); }

// components/forms/QuantityStepper.jsx
try { (() => {
function QuantityStepper({
  value,
  defaultValue = 1,
  min = 1,
  max = 10,
  onChange,
  size = "md",
  style
}) {
  const [v, setV] = React.useState(defaultValue);
  const cur = value != null ? value : v;
  const set = n => {
    n = Math.max(min, Math.min(max, n));
    setV(n);
    onChange && onChange(n);
  };
  const h = size === "sm" ? 36 : 44;
  const b = (dis, ic, fn) => /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: fn,
    disabled: dis,
    style: {
      width: h,
      height: h - 2,
      border: 0,
      background: "transparent",
      color: "var(--ink-900)",
      cursor: dis ? "not-allowed" : "pointer",
      opacity: dis ? .3 : 1,
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      padding: 0
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: ic,
    size: 16
  }));
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      height: h,
      border: "1px solid var(--border-2)",
      borderRadius: "var(--radius-pill)",
      background: "var(--white)",
      ...style
    }
  }, b(cur <= min, "minus", () => set(cur - 1)), /*#__PURE__*/React.createElement("span", {
    style: {
      minWidth: 24,
      textAlign: "center",
      fontFamily: "var(--font-mono)",
      fontSize: 15
    }
  }, cur), b(cur >= max, "plus", () => set(cur + 1)));
}
Object.assign(__ds_scope, { QuantityStepper });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/QuantityStepper.jsx", error: String((e && e.message) || e) }); }

// components/forms/Radio.jsx
try { (() => {
function Radio({
  options = [],
  value,
  defaultValue,
  onChange,
  name = "radio",
  direction = "column",
  style
}) {
  const [v, setV] = React.useState(defaultValue);
  const cur = value != null ? value : v;
  return /*#__PURE__*/React.createElement("div", {
    role: "radiogroup",
    style: {
      display: "flex",
      flexDirection: direction,
      gap: direction === "row" ? 20 : 12,
      ...style
    }
  }, options.map(o => {
    const opt = typeof o === "string" ? {
      value: o,
      label: o
    } : o;
    const on = cur === opt.value;
    return /*#__PURE__*/React.createElement("label", {
      key: opt.value,
      onClick: () => {
        setV(opt.value);
        onChange && onChange(opt.value);
      },
      style: {
        display: "flex",
        alignItems: "flex-start",
        gap: 10,
        cursor: "pointer",
        fontSize: 15
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        flex: "none",
        marginTop: 1,
        width: 20,
        height: 20,
        borderRadius: 999,
        border: `1.5px solid ${on ? "var(--ink-900)" : "var(--ink-300)"}`,
        background: "var(--white)",
        display: "inline-flex",
        alignItems: "center",
        justifyContent: "center"
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        width: 10,
        height: 10,
        borderRadius: 999,
        background: "var(--ink-900)",
        transform: on ? "scale(1)" : "scale(0)",
        transition: "transform var(--dur-base) var(--ease-out)"
      }
    })), /*#__PURE__*/React.createElement("span", {
      style: {
        display: "flex",
        flexDirection: "column",
        gap: 2
      }
    }, /*#__PURE__*/React.createElement("span", null, opt.label), opt.description && /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 13,
        color: "var(--fg-2)"
      }
    }, opt.description)));
  }));
}
Object.assign(__ds_scope, { Radio });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Radio.jsx", error: String((e && e.message) || e) }); }

// components/forms/Select.jsx
try { (() => {
const Label = ({
  children
}) => /*#__PURE__*/React.createElement("span", {
  style: {
    fontSize: 13,
    fontWeight: 600,
    color: "var(--fg-1)"
  }
}, children);
const Help = ({
  children,
  error
}) => /*#__PURE__*/React.createElement("span", {
  style: {
    fontSize: 13,
    color: error ? "var(--danger-600)" : "var(--fg-2)"
  }
}, children);
function Select({
  label,
  options = [],
  value,
  defaultValue,
  onChange,
  placeholder,
  help,
  disabled = false,
  style
}) {
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 6,
      ...style
    }
  }, label && /*#__PURE__*/React.createElement(Label, null, label), /*#__PURE__*/React.createElement("span", {
    style: {
      position: "relative",
      display: "flex"
    }
  }, /*#__PURE__*/React.createElement("select", {
    value: value,
    defaultValue: defaultValue,
    onChange: onChange,
    disabled: disabled,
    style: {
      appearance: "none",
      WebkitAppearance: "none",
      width: "100%",
      height: "var(--control-h-md)",
      padding: "0 40px 0 14px",
      background: "var(--white)",
      border: "1px solid var(--border-2)",
      borderRadius: "var(--radius-sm)",
      font: "inherit",
      fontSize: 15,
      color: "var(--fg-1)",
      cursor: "pointer"
    }
  }, placeholder && /*#__PURE__*/React.createElement("option", {
    value: ""
  }, placeholder), options.map(o => {
    const v = typeof o === "string" ? {
      value: o,
      label: o
    } : o;
    return /*#__PURE__*/React.createElement("option", {
      key: v.value,
      value: v.value
    }, v.label);
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      position: "absolute",
      right: 14,
      top: "50%",
      transform: "translateY(-50%)",
      pointerEvents: "none",
      color: "var(--fg-2)"
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "chevron-down",
    size: 18
  }))), help && /*#__PURE__*/React.createElement(Help, null, help));
}
Object.assign(__ds_scope, { Select });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Select.jsx", error: String((e && e.message) || e) }); }

// components/forms/Switch.jsx
try { (() => {
function Switch({
  label,
  checked,
  defaultChecked = false,
  onChange,
  disabled = false,
  style
}) {
  const [c, setC] = React.useState(defaultChecked);
  const on = checked != null ? checked : c;
  return /*#__PURE__*/React.createElement("label", {
    onClick: e => {
      e.preventDefault();
      if (disabled) return;
      setC(!on);
      onChange && onChange(!on);
    },
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 12,
      cursor: disabled ? "not-allowed" : "pointer",
      opacity: disabled ? .45 : 1,
      fontSize: 15,
      ...style
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: "relative",
      width: 42,
      height: 24,
      borderRadius: 999,
      background: on ? "var(--ink-900)" : "var(--ink-200)",
      transition: "background var(--dur-base) var(--ease-out)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: "absolute",
      top: 3,
      left: on ? 21 : 3,
      width: 18,
      height: 18,
      borderRadius: 999,
      background: on ? "var(--pulse-400)" : "var(--white)",
      boxShadow: "var(--shadow-1)",
      transition: "left var(--dur-base) var(--ease-out),background var(--dur-base) var(--ease-out)"
    }
  })), label);
}
Object.assign(__ds_scope, { Switch });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Switch.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Accordion.jsx
try { (() => {
function Accordion({
  items = [],
  defaultOpen = null,
  style
}) {
  const [o, setO] = React.useState(defaultOpen);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      borderTop: "1px solid var(--border-2)",
      ...style
    }
  }, items.map((it, i) => {
    const on = o === i;
    return /*#__PURE__*/React.createElement("div", {
      key: i,
      style: {
        borderBottom: "1px solid var(--border-2)"
      }
    }, /*#__PURE__*/React.createElement("button", {
      type: "button",
      onClick: () => setO(on ? null : i),
      "aria-expanded": on,
      style: {
        width: "100%",
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
        gap: 16,
        padding: "20px 0",
        border: 0,
        background: "transparent",
        font: "inherit",
        fontSize: 17,
        fontWeight: 600,
        color: "var(--fg-1)",
        textAlign: "left",
        cursor: "pointer"
      }
    }, it.title, /*#__PURE__*/React.createElement("span", {
      style: {
        flex: "none",
        transform: on ? "rotate(45deg)" : "none",
        transition: "transform var(--dur-base) var(--ease-out)"
      }
    }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
      name: "plus",
      size: 20
    }))), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "grid",
        gridTemplateRows: on ? "1fr" : "0fr",
        transition: "grid-template-rows var(--dur-slow) var(--ease-out)"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        overflow: "hidden"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        paddingBottom: 20,
        color: "var(--fg-2)",
        fontSize: 15,
        lineHeight: 1.6,
        maxWidth: 640
      }
    }, it.content))));
  }));
}
Object.assign(__ds_scope, { Accordion });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Accordion.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Tabs.jsx
try { (() => {
function Tabs({
  tabs = [],
  value,
  defaultValue,
  onChange,
  variant = "underline",
  style
}) {
  const [v, setV] = React.useState(defaultValue || tabs[0] && (tabs[0].value || tabs[0]));
  const cur = value != null ? value : v;
  const pill = variant === "pill";
  return /*#__PURE__*/React.createElement("div", {
    role: "tablist",
    style: {
      display: "flex",
      gap: pill ? 4 : 28,
      padding: pill ? 4 : 0,
      background: pill ? "var(--ink-100)" : "transparent",
      borderRadius: pill ? 999 : 0,
      borderBottom: pill ? 0 : "1px solid var(--border-1)",
      width: pill ? "fit-content" : undefined,
      ...style
    }
  }, tabs.map(t => {
    const o = typeof t === "string" ? {
      value: t,
      label: t
    } : t;
    const on = o.value === cur;
    return /*#__PURE__*/React.createElement("button", {
      key: o.value,
      role: "tab",
      "aria-selected": on,
      onClick: () => {
        setV(o.value);
        onChange && onChange(o.value);
      },
      style: pill ? {
        height: 36,
        padding: "0 18px",
        border: 0,
        borderRadius: 999,
        background: on ? "var(--white)" : "transparent",
        boxShadow: on ? "var(--shadow-1)" : "none",
        color: on ? "var(--fg-1)" : "var(--fg-2)",
        font: "inherit",
        fontSize: 14,
        fontWeight: 600,
        cursor: "pointer",
        transition: "all var(--dur-base) var(--ease-out)"
      } : {
        height: 44,
        padding: 0,
        border: 0,
        borderBottom: `2px solid ${on ? "var(--ink-900)" : "transparent"}`,
        marginBottom: -1,
        background: "transparent",
        color: on ? "var(--fg-1)" : "var(--fg-2)",
        font: "inherit",
        fontSize: 15,
        fontWeight: 600,
        cursor: "pointer",
        transition: "color var(--dur-base) var(--ease-out),border-color var(--dur-base) var(--ease-out)"
      }
    }, o.label);
  }));
}
Object.assign(__ds_scope, { Tabs });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Tabs.jsx", error: String((e && e.message) || e) }); }

// site/Accessories.jsx
try { (() => {
const {
  Button,
  IconButton,
  Badge,
  Tag,
  Card,
  Icon,
  Input,
  Select,
  Radio,
  Checkbox,
  Switch,
  QuantityStepper,
  ColorSwatchPicker,
  Tabs,
  Accordion,
  Dialog,
  Toast,
  MetricStat,
  ProductMedia,
  PriceTag,
  Tooltip
} = window.OVFLEDesignSystem_b73ae2;
function Accessories({
  go,
  add
}) {
  const S = window.SITE;
  const m = useMobile();
  const [cw, setCw] = React.useState("deep-teal");
  const c = S.colors.find(x => x.id === cw);
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Wrap, {
    style: {
      paddingTop: m ? 32 : 64
    }
  }, /*#__PURE__*/React.createElement(Eyebrow, null, "Accessoires"), /*#__PURE__*/React.createElement("h1", {
    style: {
      margin: 0,
      fontFamily: "var(--font-display)",
      fontStretch: "112%",
      fontWeight: 800,
      fontSize: m ? 44 : "clamp(44px,5.5vw,68px)",
      lineHeight: .96,
      letterSpacing: "-.035em"
    }
  }, "Un module, plusieurs bracelets.")), /*#__PURE__*/React.createElement(Section, {
    style: {
      paddingTop: m ? 28 : 48,
      display: "grid",
      gridTemplateColumns: m ? "1fr" : "1fr 1fr",
      gap: m ? 24 : 56,
      alignItems: "center"
    }
  }, /*#__PURE__*/React.createElement(Photo, {
    color: c,
    label: "Bracelet · " + c.name + " · photo à venir"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 20
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Badge, {
    tone: "teal"
  }, "8 couleurs"), /*#__PURE__*/React.createElement("h2", {
    style: {
      margin: "14px 0 0",
      fontFamily: "var(--font-display)",
      fontStretch: "112%",
      fontWeight: 700,
      fontSize: m ? 32 : 44,
      letterSpacing: "-.025em",
      lineHeight: 1.05
    }
  }, "Bracelet tiss\xE9"), /*#__PURE__*/React.createElement("p", {
    style: {
      color: "var(--fg-2)",
      margin: "10px 0 0"
    }
  }, "Tissu tress\xE9 \xE9lastique, sans boucle. Compatible avec tous les modules WP-1.")), /*#__PURE__*/React.createElement(PriceTag, {
    size: "lg",
    price: S.products.strap.price,
    format: S.eur
  }), /*#__PURE__*/React.createElement(ColorSwatchPicker, {
    options: S.colors.map(x => ({
      id: x.id,
      name: x.name,
      color: x.tone
    })),
    value: cw,
    onChange: setCw
  }), /*#__PURE__*/React.createElement(Button, {
    iconLeft: "shopping-bag",
    onClick: () => add("strap", cw),
    style: {
      alignSelf: "flex-start"
    }
  }, "Ajouter au panier"))), /*#__PURE__*/React.createElement(Section, null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: m ? "1fr" : "repeat(3,1fr)",
      gap: 16
    }
  }, /*#__PURE__*/React.createElement(ProductTile, {
    p: S.products.wp1,
    color: S.colors[0],
    onAdd: () => add("wp1", "black"),
    go: () => go("/produit")
  }), /*#__PURE__*/React.createElement(ProductTile, {
    p: S.products.pack,
    onAdd: () => add("pack")
  }), /*#__PURE__*/React.createElement(ProductTile, {
    p: S.products.charger,
    onAdd: () => add("charger")
  }))));
}
window.Accessories = Accessories;
})(); } catch (e) { __ds_ns.__errors.push({ path: "site/Accessories.jsx", error: String((e && e.message) || e) }); }

// site/Cart.jsx
try { (() => {
const {
  Button,
  IconButton,
  Badge,
  Tag,
  Card,
  Icon,
  Input,
  Select,
  Radio,
  Checkbox,
  Switch,
  QuantityStepper,
  ColorSwatchPicker,
  Tabs,
  Accordion,
  Dialog,
  Toast,
  MetricStat,
  ProductMedia,
  PriceTag,
  Tooltip
} = window.OVFLEDesignSystem_b73ae2;
function lineInfo(it) {
  const S = window.SITE;
  const p = S.products[it.id];
  const c = it.color && S.colors.find(x => x.id === it.color);
  return {
    p,
    c,
    total: p.price * it.qty
  };
}
function CartLines({
  items,
  setQty,
  remove,
  compact
}) {
  const S = window.SITE;
  if (!items.length) return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "56px 0",
      textAlign: "center",
      color: "var(--fg-2)",
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      gap: 12
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "shopping-bag",
    size: 28
  }), "Votre panier est vide.");
  return /*#__PURE__*/React.createElement("div", null, items.map((it, i) => {
    const {
      p,
      c,
      total
    } = lineInfo(it);
    return /*#__PURE__*/React.createElement("div", {
      key: i,
      style: {
        display: "grid",
        gridTemplateColumns: (compact ? "72px" : "96px") + " 1fr auto",
        gap: 16,
        padding: "16px 0",
        borderBottom: "1px solid var(--border-1)",
        alignItems: "center"
      }
    }, c ? /*#__PURE__*/React.createElement(Photo, {
      color: c,
      radius: "md",
      label: " "
    }) : /*#__PURE__*/React.createElement(ProductMedia, {
      radius: "md",
      tone: "var(--paper-50)",
      src: it.id === "pack" ? "assets/wp1-grid.jpg" : undefined,
      label: " "
    }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      style: {
        fontWeight: 600
      }
    }, p.short), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 14,
        color: "var(--fg-2)",
        marginBottom: 10
      }
    }, c ? c.name : p.sub), /*#__PURE__*/React.createElement(QuantityStepper, {
      size: "sm",
      value: it.qty,
      max: 5,
      onChange: n => setQty(i, n)
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        flexDirection: "column",
        alignItems: "flex-end",
        gap: 10
      }
    }, /*#__PURE__*/React.createElement(PriceTag, {
      price: total,
      size: "sm",
      format: S.eur
    }), /*#__PURE__*/React.createElement(IconButton, {
      icon: "trash-2",
      label: "Retirer",
      size: "sm",
      onClick: () => remove(i)
    })));
  }));
}
function CartDrawer({
  open,
  items,
  setQty,
  remove,
  onClose,
  go,
  subtotal
}) {
  const S = window.SITE;
  const m = useMobile();
  const free = 40;
  const left = Math.max(0, free - subtotal);
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    onClick: onClose,
    style: {
      position: "fixed",
      inset: 0,
      zIndex: 50,
      background: "rgba(14,15,13,.42)",
      opacity: open ? 1 : 0,
      pointerEvents: open ? "auto" : "none",
      transition: "opacity var(--dur-slow) var(--ease-out)"
    }
  }), /*#__PURE__*/React.createElement("aside", {
    "aria-hidden": !open,
    style: {
      position: "fixed",
      top: 0,
      right: 0,
      bottom: 0,
      width: m ? "100%" : 420,
      zIndex: 51,
      background: "var(--bg-page)",
      boxShadow: open ? "var(--shadow-3)" : "none",
      visibility: open ? "visible" : "hidden",
      transform: open ? "none" : "translateX(100%)",
      transition: open ? "transform var(--dur-slow) var(--ease-out)" : "transform var(--dur-slow) var(--ease-out),visibility 0s linear var(--dur-slow),box-shadow 0s linear var(--dur-slow)",
      display: "flex",
      flexDirection: "column"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      padding: "16px 20px",
      borderBottom: "1px solid var(--border-1)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-display)",
      fontStretch: "112%",
      fontWeight: 700,
      fontSize: 22,
      letterSpacing: "-.02em"
    }
  }, "Panier"), /*#__PURE__*/React.createElement(IconButton, {
    icon: "x",
    label: "Fermer",
    onClick: onClose
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      overflow: "auto",
      padding: "4px 20px"
    }
  }, /*#__PURE__*/React.createElement(CartLines, {
    items: items,
    setQty: setQty,
    remove: remove,
    compact: true
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 20,
      borderTop: "1px solid var(--border-1)",
      display: "flex",
      flexDirection: "column",
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--fg-2)"
    }
  }, "Sous-total"), /*#__PURE__*/React.createElement(PriceTag, {
    price: subtotal,
    size: "sm",
    format: S.eur
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      color: "var(--fg-2)"
    }
  }, "Livraison offerte. Taxes incluses."), /*#__PURE__*/React.createElement(Button, {
    variant: "accent",
    size: "lg",
    fullWidth: true,
    disabled: !items.length,
    iconRight: "arrow-right",
    onClick: () => {
      onClose();
      go("/commande");
    }
  }, "Passer la commande"), /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    size: "sm",
    fullWidth: true,
    onClick: () => {
      onClose();
      go("/panier");
    }
  }, "Voir le panier"))));
}
function CartPage({
  items,
  setQty,
  remove,
  go,
  add,
  subtotal
}) {
  const S = window.SITE;
  const m = useMobile();
  const hasCharger = items.some(i => i.id === "charger");
  return /*#__PURE__*/React.createElement(Wrap, {
    style: {
      paddingTop: m ? 32 : 56,
      display: "grid",
      gridTemplateColumns: m ? "1fr" : "minmax(0,1.5fr) minmax(0,1fr)",
      gap: m ? 32 : 56,
      alignItems: "start"
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h1", {
    style: {
      margin: "0 0 12px",
      fontFamily: "var(--font-display)",
      fontStretch: "112%",
      fontWeight: 800,
      fontSize: m ? 40 : 56,
      letterSpacing: "-.03em",
      lineHeight: 1
    }
  }, "Panier"), /*#__PURE__*/React.createElement(CartLines, {
    items: items,
    setQty: setQty,
    remove: remove
  }), !hasCharger && /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 32
    }
  }, /*#__PURE__*/React.createElement(Eyebrow, null, "Souvent ajout\xE9"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: m ? "1fr" : "1fr 1fr",
      gap: 12
    }
  }, /*#__PURE__*/React.createElement(ProductTile, {
    p: S.products.charger,
    onAdd: () => add("charger")
  }), /*#__PURE__*/React.createElement(ProductTile, {
    p: S.products.strap,
    color: S.colors[1],
    onAdd: () => add("strap", "beige")
  })))), /*#__PURE__*/React.createElement(Card, {
    variant: "sunken",
    padding: m ? 20 : 28,
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 14,
      position: m ? "static" : "sticky",
      top: 100
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-display)",
      fontStretch: "112%",
      fontWeight: 700,
      fontSize: 22,
      letterSpacing: "-.02em"
    }
  }, "R\xE9capitulatif"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      fontSize: 15
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--fg-2)"
    }
  }, "Sous-total"), /*#__PURE__*/React.createElement("span", null, S.eur(subtotal))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      fontSize: 15
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--fg-2)"
    }
  }, "Livraison"), /*#__PURE__*/React.createElement("span", null, "Offerte")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "baseline",
      borderTop: "1px solid var(--border-2)",
      paddingTop: 14
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 600
    }
  }, "Total TTC"), /*#__PURE__*/React.createElement(PriceTag, {
    price: subtotal,
    format: S.eur
  })), /*#__PURE__*/React.createElement(Button, {
    variant: "accent",
    size: "lg",
    fullWidth: true,
    disabled: !items.length,
    iconRight: "lock",
    onClick: () => go("/commande")
  }, "Paiement s\xE9curis\xE9"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "center",
      gap: 6,
      flexWrap: "wrap"
    }
  }, ["CB", "Visa", "Mastercard", "PayPal", "Apple Pay", "Google Pay"].map(x => /*#__PURE__*/React.createElement(Badge, {
    key: x
  }, x)))));
}
Object.assign(window, {
  CartDrawer,
  CartPage,
  CartLines,
  lineInfo
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "site/Cart.jsx", error: String((e && e.message) || e) }); }

// site/Checkout.jsx
try { (() => {
const {
  Button,
  IconButton,
  Badge,
  Tag,
  Card,
  Icon,
  Input,
  Select,
  Radio,
  Checkbox,
  Switch,
  QuantityStepper,
  ColorSwatchPicker,
  Tabs,
  Accordion,
  Dialog,
  Toast,
  MetricStat,
  ProductMedia,
  PriceTag,
  Tooltip
} = window.OVFLEDesignSystem_b73ae2;
function ExpressPay({
  onPay
}) {
  const b = (l, bg, fg, bd) => /*#__PURE__*/React.createElement("button", {
    key: l,
    onClick: onPay,
    style: {
      flex: 1,
      minWidth: 0,
      height: 48,
      borderRadius: "var(--radius-pill)",
      border: bd || 0,
      background: bg,
      color: fg,
      font: "600 16px var(--font-body)",
      letterSpacing: "-.01em",
      cursor: "pointer"
    }
  }, l);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 10
    }
  }, b("Apple Pay", "#000", "#fff"), b("Google Pay", "#fff", "#1f1f1f", "1px solid var(--border-2)"), b("PayPal", "#FFC439", "#003087"));
}
function Checkout({
  items,
  subtotal,
  go,
  placeOrder
}) {
  const S = window.SITE;
  const m = useMobile();
  const [ship, setShip] = React.useState("standard");
  const [pay, setPay] = React.useState("card");
  const [promo, setPromo] = React.useState("");
  const [applied, setApplied] = React.useState(false);
  const [busy, setBusy] = React.useState(false);
  const [err, setErr] = React.useState(false);
  const sp = S.shipping.find(s => s.value === ship).price;
  const disc = applied ? Math.round(subtotal * 10) / 100 : 0;
  const total = subtotal + sp - disc;
  const submit = () => {
    if (!items.length) {
      setErr(true);
      return;
    }
    setBusy(true);
    setTimeout(() => {
      setBusy(false);
      placeOrder({
        total,
        pay
      });
    }, 900);
  };
  const Sum = /*#__PURE__*/React.createElement(Card, {
    variant: "sunken",
    padding: m ? 20 : 28,
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 16,
      position: m ? "static" : "sticky",
      top: 100
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-display)",
      fontStretch: "112%",
      fontWeight: 700,
      fontSize: 22,
      letterSpacing: "-.02em"
    }
  }, "Votre commande"), items.map((it, i) => {
    const {
      p,
      c,
      total
    } = lineInfo(it);
    return /*#__PURE__*/React.createElement("div", {
      key: i,
      style: {
        display: "grid",
        gridTemplateColumns: "56px 1fr auto",
        gap: 14,
        alignItems: "center"
      }
    }, c ? /*#__PURE__*/React.createElement(Photo, {
      color: c,
      radius: "sm",
      label: " "
    }) : /*#__PURE__*/React.createElement(ProductMedia, {
      radius: "sm",
      tone: "var(--white)",
      label: " "
    }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      style: {
        fontWeight: 600,
        fontSize: 15
      }
    }, p.short, " \xD7 ", it.qty), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 13,
        color: "var(--fg-2)"
      }
    }, c ? c.name : p.sub)), /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 15
      }
    }, S.eur(total)));
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 8,
      alignItems: "flex-end"
    }
  }, /*#__PURE__*/React.createElement(Input, {
    label: "Code promo",
    placeholder: "BIENVENUE10",
    value: promo,
    onChange: e => setPromo(e.target.value),
    style: {
      flex: 1
    },
    help: applied ? "−10 % appliqué" : undefined
  }), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    onClick: () => setApplied(promo.trim().length > 0),
    style: {
      marginBottom: applied ? 25 : 0
    }
  }, "Appliquer")), /*#__PURE__*/React.createElement("div", {
    style: {
      borderTop: "1px solid var(--border-2)",
      paddingTop: 16,
      display: "flex",
      flexDirection: "column",
      gap: 8,
      fontSize: 15
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--fg-2)"
    }
  }, "Sous-total"), /*#__PURE__*/React.createElement("span", null, S.eur(subtotal))), applied && /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--fg-2)"
    }
  }, "Remise"), /*#__PURE__*/React.createElement("span", null, "\u2212", S.eur(disc))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--fg-2)"
    }
  }, "Livraison"), /*#__PURE__*/React.createElement("span", null, sp ? S.eur(sp) : "Offerte")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "baseline",
      marginTop: 6
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 600
    }
  }, "Total TTC"), /*#__PURE__*/React.createElement(PriceTag, {
    price: total,
    format: S.eur
  }))));
  return /*#__PURE__*/React.createElement(Wrap, {
    style: {
      paddingTop: m ? 24 : 48,
      display: "grid",
      gridTemplateColumns: m ? "1fr" : "minmax(0,1.3fr) minmax(0,1fr)",
      gap: m ? 28 : 56,
      alignItems: "start"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 28
    }
  }, /*#__PURE__*/React.createElement("h1", {
    style: {
      margin: 0,
      fontFamily: "var(--font-display)",
      fontStretch: "112%",
      fontWeight: 800,
      fontSize: m ? 40 : 48,
      letterSpacing: "-.03em",
      lineHeight: 1
    }
  }, "Commande"), m && Sum, /*#__PURE__*/React.createElement("section", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 12
    }
  }, /*#__PURE__*/React.createElement(Eyebrow, {
    style: {
      marginBottom: 0
    }
  }, "Paiement express"), /*#__PURE__*/React.createElement(ExpressPay, {
    onPay: submit
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 12,
      color: "var(--fg-3)",
      fontSize: 13
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      height: 1,
      background: "var(--border-1)"
    }
  }), "ou", /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      height: 1,
      background: "var(--border-1)"
    }
  }))), /*#__PURE__*/React.createElement("section", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 14
    }
  }, /*#__PURE__*/React.createElement(Eyebrow, {
    style: {
      marginBottom: 0
    }
  }, "01 \xB7 Coordonn\xE9es"), /*#__PURE__*/React.createElement(Input, {
    label: "E-mail",
    type: "email",
    placeholder: "vous@exemple.fr",
    help: "Pour la confirmation et le suivi"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr",
      gap: 14
    }
  }, /*#__PURE__*/React.createElement(Input, {
    label: "Pr\xE9nom",
    placeholder: "Camille"
  }), /*#__PURE__*/React.createElement(Input, {
    label: "Nom",
    placeholder: "Martin"
  })), /*#__PURE__*/React.createElement(Input, {
    label: "T\xE9l\xE9phone",
    prefix: "+33",
    placeholder: "6 12 34 56 78"
  })), /*#__PURE__*/React.createElement("section", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 14
    }
  }, /*#__PURE__*/React.createElement(Eyebrow, {
    style: {
      marginBottom: 0
    }
  }, "02 \xB7 Livraison"), /*#__PURE__*/React.createElement(Input, {
    label: "Adresse",
    placeholder: "12 rue de la R\xE9publique"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: m ? "1fr 1.4fr" : "1fr 1.4fr 1fr",
      gap: 14
    }
  }, /*#__PURE__*/React.createElement(Input, {
    label: "Code postal",
    placeholder: "75011"
  }), /*#__PURE__*/React.createElement(Input, {
    label: "Ville",
    placeholder: "Paris"
  }), !m && /*#__PURE__*/React.createElement(Select, {
    label: "Pays",
    defaultValue: "FR",
    options: [{
      value: "FR",
      label: "France"
    }, {
      value: "BE",
      label: "Belgique"
    }, {
      value: "CH",
      label: "Suisse"
    }, {
      value: "LU",
      label: "Luxembourg"
    }]
  })), m && /*#__PURE__*/React.createElement(Select, {
    label: "Pays",
    defaultValue: "FR",
    options: [{
      value: "FR",
      label: "France"
    }, {
      value: "BE",
      label: "Belgique"
    }, {
      value: "CH",
      label: "Suisse"
    }, {
      value: "LU",
      label: "Luxembourg"
    }]
  }), /*#__PURE__*/React.createElement(Card, {
    padding: 18,
    radius: "md"
  }, /*#__PURE__*/React.createElement(Radio, {
    value: ship,
    onChange: setShip,
    options: S.shipping
  }))), /*#__PURE__*/React.createElement("section", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 14
    }
  }, /*#__PURE__*/React.createElement(Eyebrow, {
    style: {
      marginBottom: 0
    }
  }, "03 \xB7 Paiement"), /*#__PURE__*/React.createElement(Card, {
    padding: 18,
    radius: "md",
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 16
    }
  }, /*#__PURE__*/React.createElement(Radio, {
    value: pay,
    onChange: setPay,
    options: [{
      value: "card",
      label: "Carte bancaire",
      description: "CB, Visa, Mastercard"
    }, {
      value: "paypal",
      label: "PayPal",
      description: "Vous serez redirigé vers PayPal"
    }]
  }), pay === "card" && /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 14,
      paddingTop: 16,
      borderTop: "1px solid var(--border-1)"
    }
  }, /*#__PURE__*/React.createElement(Input, {
    label: "Num\xE9ro de carte",
    icon: "credit-card",
    placeholder: "1234 5678 9012 3456"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr",
      gap: 14
    }
  }, /*#__PURE__*/React.createElement(Input, {
    label: "Expiration",
    placeholder: "MM / AA"
  }), /*#__PURE__*/React.createElement(Input, {
    label: "CVC",
    placeholder: "123"
  })), /*#__PURE__*/React.createElement(Input, {
    label: "Titulaire",
    placeholder: "Camille Martin"
  }))), /*#__PURE__*/React.createElement(Checkbox, {
    label: "Recevoir les nouveaut\xE9s OVFLE par e-mail"
  }), /*#__PURE__*/React.createElement(Button, {
    variant: "accent",
    size: "lg",
    fullWidth: true,
    iconLeft: busy ? undefined : "lock",
    onClick: submit,
    disabled: busy
  }, busy ? "Traitement…" : pay === "paypal" ? "Continuer avec PayPal" : "Payer " + S.eur(total)), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 13,
      color: "var(--fg-2)",
      display: "flex",
      alignItems: "center",
      gap: 8
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "shield-check",
    size: 16
  }), "Paiement chiffr\xE9. Retours gratuits sous 30 jours."))), !m && Sum, /*#__PURE__*/React.createElement(Dialog, {
    open: err,
    onClose: () => setErr(false),
    title: "Votre panier est vide",
    footer: /*#__PURE__*/React.createElement(Button, {
      onClick: () => {
        setErr(false);
        go("/produit");
      }
    }, "Voir le WP-1")
  }, "Ajoutez un article avant de passer commande."));
}
function Confirmation({
  go,
  order
}) {
  const S = window.SITE;
  const m = useMobile();
  return /*#__PURE__*/React.createElement(Wrap, {
    style: {
      paddingTop: m ? 64 : 120,
      display: "flex",
      flexDirection: "column",
      alignItems: "flex-start",
      gap: 20,
      maxWidth: 760
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "check-circle-2",
    size: 40,
    color: "var(--success-600)"
  }), /*#__PURE__*/React.createElement(Eyebrow, {
    style: {
      marginBottom: 0
    }
  }, "Commande n\xB0 OV-48213"), /*#__PURE__*/React.createElement("h1", {
    style: {
      margin: 0,
      fontFamily: "var(--font-display)",
      fontStretch: "112%",
      fontWeight: 800,
      fontSize: m ? 44 : "clamp(44px,5.5vw,68px)",
      lineHeight: .96,
      letterSpacing: "-.035em"
    }
  }, "Merci. Votre WP-1 est en route."), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      color: "var(--fg-2)",
      fontSize: 18,
      maxWidth: 540
    }
  }, order ? "Total réglé : " + S.eur(order.total) + ". " : "", "Un e-mail de confirmation vient de partir. Vous recevrez le lien de suivi d\xE8s l'exp\xE9dition."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 10,
      flexWrap: "wrap"
    }
  }, /*#__PURE__*/React.createElement(Button, {
    onClick: () => go("/fonctionnement")
  }, "Pr\xE9parer l'application"), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    onClick: () => go("/")
  }, "Retour \xE0 l'accueil")));
}
Object.assign(window, {
  Checkout,
  Confirmation
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "site/Checkout.jsx", error: String((e && e.message) || e) }); }

// site/Colors.jsx
try { (() => {
const {
  Button,
  IconButton,
  Badge,
  Tag,
  Card,
  Icon,
  Input,
  Select,
  Radio,
  Checkbox,
  Switch,
  QuantityStepper,
  ColorSwatchPicker,
  Tabs,
  Accordion,
  Dialog,
  Toast,
  MetricStat,
  ProductMedia,
  PriceTag,
  Tooltip
} = window.OVFLEDesignSystem_b73ae2;
function Colors({
  go,
  add
}) {
  const S = window.SITE;
  const m = useMobile();
  const [sel, setSel] = React.useState(["black", "deep-teal"]);
  const toggle = id => setSel(s => s.includes(id) ? s.length > 1 ? s.filter(x => x !== id) : s : [s[s.length - 1], id]);
  const pick = sel.map(id => S.colors.find(c => c.id === id));
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Wrap, {
    style: {
      paddingTop: m ? 32 : 64
    }
  }, /*#__PURE__*/React.createElement(Eyebrow, null, "Comparatif"), /*#__PURE__*/React.createElement("h1", {
    style: {
      margin: 0,
      fontFamily: "var(--font-display)",
      fontStretch: "112%",
      fontWeight: 800,
      fontSize: m ? 44 : "clamp(44px,5.5vw,68px)",
      lineHeight: .96,
      letterSpacing: "-.035em",
      maxWidth: 800
    }
  }, "Huit couleurs. Un seul bracelet."), /*#__PURE__*/React.createElement("p", {
    style: {
      color: "var(--fg-2)",
      fontSize: 17,
      maxWidth: 540,
      margin: "18px 0 0"
    }
  }, "S\xE9lectionnez deux couleurs pour les voir c\xF4te \xE0 c\xF4te. M\xEAme module, m\xEAme prix, m\xEAme autonomie.")), /*#__PURE__*/React.createElement(Wrap, {
    style: {
      paddingTop: m ? 28 : 40
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: m ? "repeat(2,1fr)" : "repeat(4,1fr)",
      gap: m ? 10 : 16
    }
  }, S.colors.map(c => {
    const on = sel.includes(c.id);
    return /*#__PURE__*/React.createElement("div", {
      key: c.id,
      onClick: () => toggle(c.id),
      style: {
        cursor: "pointer",
        display: "flex",
        flexDirection: "column",
        gap: 10
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        borderRadius: "var(--radius-lg)",
        outline: on ? "1.5px solid var(--ink-900)" : "1.5px solid transparent",
        outlineOffset: 3,
        position: "relative"
      }
    }, /*#__PURE__*/React.createElement(Photo, {
      color: c,
      radius: "lg",
      label: c.img ? " " : "Photo à venir"
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        position: "absolute",
        top: 10,
        right: 10,
        width: 26,
        height: 26,
        borderRadius: 999,
        background: on ? "var(--ink-900)" : "rgba(250,249,245,.85)",
        color: "var(--paper-0)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        border: on ? 0 : "1px solid var(--border-2)"
      }
    }, on && /*#__PURE__*/React.createElement(Icon, {
      name: "check",
      size: 15,
      strokeWidth: 2.5
    }))), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        alignItems: "center",
        gap: 8
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        width: 12,
        height: 12,
        borderRadius: 99,
        background: c.tone,
        boxShadow: "inset 0 0 0 1px rgba(0,0,0,.15)"
      }
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        fontWeight: 600
      }
    }, c.name)));
  }))), /*#__PURE__*/React.createElement(Section, null, /*#__PURE__*/React.createElement(Eyebrow, null, "C\xF4te \xE0 c\xF4te"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr",
      gap: m ? 10 : 24,
      marginTop: 8
    }
  }, pick.map(c => /*#__PURE__*/React.createElement(Card, {
    key: c.id,
    padding: m ? 12 : 20,
    style: {
      display: "flex",
      flexDirection: "column",
      gap: m ? 12 : 16
    }
  }, /*#__PURE__*/React.createElement(Photo, {
    color: c,
    radius: "md",
    label: c.img ? " " : "Photo à venir"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-display)",
      fontStretch: "112%",
      fontWeight: 700,
      fontSize: m ? 20 : 28,
      letterSpacing: "-.02em"
    }
  }, c.name), [["Bracelet", "Tissu tressé"], ["Fermoir", c.clasp.replace("Fermoir ", "")], ["Style", c.mood]].map(([k, v]) => /*#__PURE__*/React.createElement("div", {
    key: k,
    style: {
      display: "flex",
      flexDirection: m ? "column" : "row",
      justifyContent: "space-between",
      gap: m ? 2 : 16,
      fontSize: 14,
      padding: "8px 0",
      borderTop: "1px solid var(--border-1)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--fg-2)"
    }
  }, k), /*#__PURE__*/React.createElement("span", {
    style: {
      textAlign: m ? "left" : "right"
    }
  }, v))), /*#__PURE__*/React.createElement(Button, {
    size: m ? "sm" : "md",
    fullWidth: true,
    onClick: () => go("/produit", c.id)
  }, "Choisir")))), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 13,
      color: "var(--fg-2)",
      marginTop: 16
    }
  }, "D\xE9j\xE0 \xE9quip\xE9 ? Chaque couleur existe en bracelet seul \xE0 ", S.eur(S.products.strap.price), ". ", /*#__PURE__*/React.createElement("a", {
    onClick: () => go("/accessoires"),
    style: {
      cursor: "pointer"
    }
  }, "Voir les accessoires"))));
}
window.Colors = Colors;
})(); } catch (e) { __ds_ns.__errors.push({ path: "site/Colors.jsx", error: String((e && e.message) || e) }); }

// site/Home.jsx
try { (() => {
const {
  Button,
  IconButton,
  Badge,
  Tag,
  Card,
  Icon,
  Input,
  Select,
  Radio,
  Checkbox,
  Switch,
  QuantityStepper,
  ColorSwatchPicker,
  Tabs,
  Accordion,
  Dialog,
  Toast,
  MetricStat,
  ProductMedia,
  PriceTag,
  Tooltip
} = window.OVFLEDesignSystem_b73ae2;
function Home({
  go,
  add
}) {
  const S = window.SITE;
  const m = useMobile();
  const [cw, setCw] = React.useState("deep-teal");
  const c = S.colors.find(x => x.id === cw);
  const feats = [["heart-pulse", "Fréquence cardiaque", "Mesurée en continu, jour et nuit."], ["droplet", "SpO₂", "Oxygénation du sang pendant le sommeil."], ["moon", "Phases de sommeil", "Léger, profond et paradoxal."], ["footprints", "Activité", "Pas, distance et calories."]];
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Wrap, {
    style: {
      display: "grid",
      gridTemplateColumns: m ? "1fr" : "minmax(0,1.05fr) minmax(0,1fr)",
      gap: m ? 32 : 56,
      alignItems: "center",
      padding: m ? "32px 16px 56px" : "72px 32px 96px"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      order: m ? 2 : 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 8,
      marginBottom: 22
    }
  }, /*#__PURE__*/React.createElement(Badge, {
    tone: "pulse"
  }, "Nouveau"), /*#__PURE__*/React.createElement(Badge, {
    tone: "teal"
  }, "\u221220 % au lancement")), /*#__PURE__*/React.createElement("h1", {
    style: {
      margin: 0,
      fontFamily: "var(--font-display)",
      fontStretch: "112%",
      fontWeight: 800,
      fontSize: m ? 52 : "clamp(52px,7.2vw,96px)",
      lineHeight: .94,
      letterSpacing: "-.035em"
    }
  }, "Pas d'\xE9cran.", /*#__PURE__*/React.createElement("br", null), "Pas de distractions."), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: m ? 16 : 18,
      color: "var(--fg-2)",
      maxWidth: 470,
      margin: "22px 0 30px",
      textWrap: "pretty"
    }
  }, "Le WP-1 p\xE8se 25 grammes. Il suit votre c\u0153ur, votre oxyg\xE9nation, votre sommeil et votre activit\xE9 en continu, puis envoie tout sur votre t\xE9l\xE9phone."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 16,
      alignItems: "center",
      flexWrap: "wrap"
    }
  }, /*#__PURE__*/React.createElement(Button, {
    size: "lg",
    iconRight: "arrow-right",
    onClick: () => go("/produit")
  }, "Acheter le WP-1"), /*#__PURE__*/React.createElement(PriceTag, {
    price: S.products.wp1.price,
    compareAt: S.products.wp1.compareAt,
    format: S.eur
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      order: m ? 1 : 2
    }
  }, /*#__PURE__*/React.createElement(Photo, {
    color: S.colors[1],
    ratio: m ? "1 / 1" : "4 / 5"
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      background: "var(--ink-900)"
    }
  }, /*#__PURE__*/React.createElement(Wrap, {
    style: {
      display: "grid",
      gridTemplateColumns: m ? "1fr 1fr" : "repeat(4,1fr)",
      gap: m ? 28 : 24,
      padding: m ? "40px 16px" : "56px 32px"
    }
  }, /*#__PURE__*/React.createElement(MetricStat, {
    inverse: true,
    size: m ? "md" : "lg",
    label: "Poids",
    icon: "feather",
    value: "25",
    unit: "g"
  }), /*#__PURE__*/React.createElement(MetricStat, {
    inverse: true,
    size: m ? "md" : "lg",
    label: "Autonomie",
    icon: "battery-full",
    value: "7\u201310",
    unit: "jours"
  }), /*#__PURE__*/React.createElement(MetricStat, {
    inverse: true,
    size: m ? "md" : "lg",
    label: "Suivi",
    icon: "activity",
    value: "24/7"
  }), /*#__PURE__*/React.createElement(MetricStat, {
    inverse: true,
    size: m ? "md" : "lg",
    label: "Couleurs",
    icon: "palette",
    value: "8"
  }))), /*#__PURE__*/React.createElement(Section, null, /*#__PURE__*/React.createElement(Eyebrow, null, "Ce qu'il mesure"), /*#__PURE__*/React.createElement(H2, {
    style: {
      maxWidth: 680
    }
  }, "Tout ce que mesure une montre connect\xE9e. Rien de ce qu'elle affiche."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: m ? "1fr 1fr" : "repeat(4,1fr)",
      gap: m ? 10 : 16,
      marginTop: m ? 28 : 40
    }
  }, feats.map(([i, t, d]) => /*#__PURE__*/React.createElement(Card, {
    key: t,
    variant: "sunken",
    padding: m ? 18 : 24,
    style: {
      minHeight: m ? 170 : 200,
      display: "flex",
      flexDirection: "column",
      justifyContent: "space-between"
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: i,
    size: 28,
    color: "var(--accent)"
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-display)",
      fontStretch: "112%",
      fontWeight: 700,
      fontSize: m ? 17 : 20,
      letterSpacing: "-.015em"
    }
  }, t), /*#__PURE__*/React.createElement("div", {
    style: {
      color: "var(--fg-2)",
      fontSize: 14,
      marginTop: 6
    }
  }, d))))), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 24
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    iconRight: "arrow-right",
    onClick: () => go("/fonctionnement")
  }, "Comment \xE7a marche"))), /*#__PURE__*/React.createElement(Section, {
    style: {
      display: "grid",
      gridTemplateColumns: m ? "1fr" : "1fr 1fr",
      gap: m ? 28 : 56,
      alignItems: "center"
    }
  }, /*#__PURE__*/React.createElement(Photo, {
    color: c
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Eyebrow, null, "8 couleurs"), /*#__PURE__*/React.createElement(H2, null, "Choisissez celle que vous oublierez porter."), /*#__PURE__*/React.createElement("p", {
    style: {
      color: "var(--fg-2)",
      fontSize: 16,
      margin: "16px 0 0"
    }
  }, c.name, " \xB7 ", c.mood), /*#__PURE__*/React.createElement(ColorSwatchPicker, {
    options: S.colors.map(x => ({
      id: x.id,
      name: x.name,
      color: x.tone
    })),
    value: cw,
    onChange: setCw,
    size: m ? 30 : 36,
    style: {
      margin: "28px 0"
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 10,
      flexWrap: "wrap"
    }
  }, /*#__PURE__*/React.createElement(Button, {
    onClick: () => go("/produit", cw)
  }, "Acheter en ", c.name.toLowerCase()), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    onClick: () => go("/couleurs")
  }, "Comparer les couleurs")))), /*#__PURE__*/React.createElement(Section, null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "flex-end",
      gap: 16,
      flexWrap: "wrap",
      marginBottom: m ? 24 : 36
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Eyebrow, null, "Accessoires"), /*#__PURE__*/React.createElement(H2, null, "Changez de bracelet en dix secondes.")), /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    iconRight: "arrow-right",
    onClick: () => go("/accessoires")
  }, "Tous les accessoires")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: m ? "1fr" : "repeat(3,1fr)",
      gap: 16
    }
  }, /*#__PURE__*/React.createElement(ProductTile, {
    p: S.products.strap,
    color: S.colors[4],
    onAdd: () => add("strap", "deep-teal")
  }), /*#__PURE__*/React.createElement(ProductTile, {
    p: S.products.pack,
    onAdd: () => add("pack")
  }), /*#__PURE__*/React.createElement(ProductTile, {
    p: S.products.charger,
    onAdd: () => add("charger")
  }))), /*#__PURE__*/React.createElement(Section, {
    style: {
      display: "grid",
      gridTemplateColumns: m ? "1fr" : "1fr 1.4fr",
      gap: m ? 24 : 56
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Eyebrow, null, "Questions"), /*#__PURE__*/React.createElement(H2, null, "Ce qu'on nous demande.")), /*#__PURE__*/React.createElement(Accordion, {
    items: S.faq,
    defaultOpen: 0
  })));
}
window.Home = Home;
})(); } catch (e) { __ds_ns.__errors.push({ path: "site/Home.jsx", error: String((e && e.message) || e) }); }

// site/HowItWorks.jsx
try { (() => {
const {
  Button,
  IconButton,
  Badge,
  Tag,
  Card,
  Icon,
  Input,
  Select,
  Radio,
  Checkbox,
  Switch,
  QuantityStepper,
  ColorSwatchPicker,
  Tabs,
  Accordion,
  Dialog,
  Toast,
  MetricStat,
  ProductMedia,
  PriceTag,
  Tooltip
} = window.OVFLEDesignSystem_b73ae2;
function HowItWorks({
  go
}) {
  const S = window.SITE;
  const m = useMobile();
  const steps = [["01", "Portez-le", "Enfilez le bracelet, oubliez-le. Il n'y a ni écran, ni notification, ni bouton."], ["02", "Il mesure", "Les capteurs relèvent votre rythme cardiaque, votre SpO₂, vos mouvements et votre sommeil en continu."], ["03", "Consultez l'app", "Ouvrez l'application quand vous le souhaitez : tendances, nuits, efforts, tout est synchronisé."]];
  const sens = [["heart-pulse", "Capteur optique", "Fréquence cardiaque au repos et à l'effort."], ["droplet", "SpO₂", "Oxygénation du sang, surtout la nuit."], ["move-3d", "Accéléromètre", "Pas, distance, calories et phases de sommeil."], ["bluetooth", "Bluetooth", "Synchronisation automatique avec votre téléphone."]];
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Wrap, {
    style: {
      paddingTop: m ? 32 : 64
    }
  }, /*#__PURE__*/React.createElement(Eyebrow, null, "Comment \xE7a marche"), /*#__PURE__*/React.createElement("h1", {
    style: {
      margin: 0,
      fontFamily: "var(--font-display)",
      fontStretch: "112%",
      fontWeight: 800,
      fontSize: m ? 44 : "clamp(44px,6.5vw,80px)",
      lineHeight: .95,
      letterSpacing: "-.035em",
      maxWidth: 900
    }
  }, "Il mesure. Vous vivez. L'app r\xE9sume.")), /*#__PURE__*/React.createElement(Section, {
    style: {
      paddingTop: m ? 32 : 56
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: m ? "1fr" : "repeat(3,1fr)",
      gap: m ? 12 : 16
    }
  }, steps.map(([n, t, d]) => /*#__PURE__*/React.createElement(Card, {
    key: n,
    variant: "sunken",
    padding: m ? 22 : 28,
    style: {
      display: "flex",
      flexDirection: "column",
      gap: m ? 24 : 48
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: 13,
      color: "var(--accent)"
    }
  }, n), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-display)",
      fontStretch: "112%",
      fontWeight: 700,
      fontSize: 26,
      letterSpacing: "-.02em"
    }
  }, t), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: "8px 0 0",
      color: "var(--fg-2)",
      fontSize: 15
    }
  }, d)))))), /*#__PURE__*/React.createElement("div", {
    style: {
      background: "var(--ink-900)",
      color: "var(--paper-0)",
      marginTop: m ? 64 : 96
    }
  }, /*#__PURE__*/React.createElement(Wrap, {
    style: {
      padding: m ? "56px 16px" : "88px 32px",
      display: "grid",
      gridTemplateColumns: m ? "1fr" : "1fr 1fr",
      gap: m ? 32 : 56,
      alignItems: "center"
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Eyebrow, {
    inverse: true
  }, "L'application"), /*#__PURE__*/React.createElement(H2, {
    style: {
      color: "var(--paper-0)"
    }
  }, "Vos donn\xE9es, quand vous le d\xE9cidez."), /*#__PURE__*/React.createElement("p", {
    style: {
      color: "var(--ink-300)",
      fontSize: 16,
      margin: "18px 0 28px",
      maxWidth: 460
    }
  }, "Score de sommeil, fr\xE9quence cardiaque sur la journ\xE9e, oxyg\xE9nation nocturne, activit\xE9 de la semaine. Gratuite, sans abonnement, sur iOS et Android."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr",
      gap: 24
    }
  }, /*#__PURE__*/React.createElement(MetricStat, {
    inverse: true,
    label: "Sommeil",
    icon: "moon",
    value: "7 h 42"
  }), /*#__PURE__*/React.createElement(MetricStat, {
    inverse: true,
    label: "Repos",
    icon: "heart-pulse",
    value: "58",
    unit: "bpm"
  }), /*#__PURE__*/React.createElement(MetricStat, {
    inverse: true,
    label: "SpO\u2082",
    icon: "droplet",
    value: "97",
    unit: "%"
  }), /*#__PURE__*/React.createElement(MetricStat, {
    inverse: true,
    label: "Pas",
    icon: "footprints",
    value: "9 214"
  })), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: 11,
      color: "var(--ink-400)",
      marginTop: 20
    }
  }, "Valeurs d'exemple")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "center"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: m ? 240 : 300,
      aspectRatio: "9 / 19",
      borderRadius: 40,
      border: "1px solid var(--border-inverse)",
      background: "var(--ink-800)",
      display: "flex",
      alignItems: "flex-end",
      justifyContent: "center",
      padding: 20,
      boxSizing: "border-box"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: 11,
      letterSpacing: ".1em",
      textTransform: "uppercase",
      color: "var(--ink-400)",
      textAlign: "center"
    }
  }, "Capture de l'application \xB7 \xE0 fournir"))))), /*#__PURE__*/React.createElement(Section, null, /*#__PURE__*/React.createElement(Eyebrow, null, "\xC0 l'int\xE9rieur"), /*#__PURE__*/React.createElement(H2, null, "Quatre capteurs, z\xE9ro \xE9cran."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: m ? "1fr 1fr" : "repeat(4,1fr)",
      gap: m ? 10 : 16,
      marginTop: m ? 24 : 36
    }
  }, sens.map(([i, t, d]) => /*#__PURE__*/React.createElement(Card, {
    key: t,
    padding: m ? 18 : 24,
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 14
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: i,
    size: 26,
    color: "var(--accent)"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 600
    }
  }, t), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14,
      color: "var(--fg-2)"
    }
  }, d))))), /*#__PURE__*/React.createElement(Section, {
    style: {
      display: "grid",
      gridTemplateColumns: m ? "1fr" : "1fr 1fr",
      gap: m ? 28 : 56,
      alignItems: "center"
    }
  }, /*#__PURE__*/React.createElement(Photo, {
    color: S.colors[1]
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Eyebrow, null, "Autonomie"), /*#__PURE__*/React.createElement(H2, null, "Une charge par semaine, environ."), /*#__PURE__*/React.createElement("p", {
    style: {
      color: "var(--fg-2)",
      fontSize: 16,
      margin: "16px 0 28px",
      maxWidth: 440
    }
  }, "Sans \xE9cran \xE0 alimenter, la batterie de 125 mAh tient 7 \xE0 10 jours. Le chargeur magn\xE9tique se clipse sur le module en une seconde."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 36
    }
  }, /*#__PURE__*/React.createElement(MetricStat, {
    size: "lg",
    label: "Autonomie",
    icon: "battery-full",
    value: "7\u201310",
    unit: "jours"
  }), /*#__PURE__*/React.createElement(MetricStat, {
    size: "lg",
    label: "Poids",
    icon: "feather",
    value: "25",
    unit: "g"
  })))), /*#__PURE__*/React.createElement(Section, {
    style: {
      display: "grid",
      gridTemplateColumns: m ? "1fr" : "1fr 1.4fr",
      gap: m ? 24 : 56
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Eyebrow, null, "Questions"), /*#__PURE__*/React.createElement(H2, null, "Avant de commander."), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 24
    }
  }, /*#__PURE__*/React.createElement(Button, {
    iconRight: "arrow-right",
    onClick: () => go("/produit")
  }, "Acheter le WP-1"))), /*#__PURE__*/React.createElement(Accordion, {
    items: S.faq
  })));
}
window.HowItWorks = HowItWorks;
})(); } catch (e) { __ds_ns.__errors.push({ path: "site/HowItWorks.jsx", error: String((e && e.message) || e) }); }

// site/Layout.jsx
try { (() => {
const {
  Button,
  IconButton,
  Badge,
  Tag,
  Card,
  Icon,
  Input,
  Select,
  Radio,
  Checkbox,
  Switch,
  QuantityStepper,
  ColorSwatchPicker,
  Tabs,
  Accordion,
  Dialog,
  Toast,
  MetricStat,
  ProductMedia,
  PriceTag,
  Tooltip
} = window.OVFLEDesignSystem_b73ae2;
function useMobile(bp = 820) {
  const [m, setM] = React.useState(window.innerWidth < bp);
  React.useEffect(() => {
    const h = () => setM(window.innerWidth < bp);
    window.addEventListener("resize", h);
    return () => window.removeEventListener("resize", h);
  }, []);
  return m;
}
const NAV = [["Le WP-1", "/produit"], ["Couleurs", "/couleurs"], ["Comment ça marche", "/fonctionnement"], ["Accessoires", "/accessoires"]];
function AnnouncementBar() {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: "var(--ink-900)",
      color: "var(--paper-0)",
      fontFamily: "var(--font-mono)",
      fontSize: 11.5,
      letterSpacing: ".08em",
      textTransform: "uppercase",
      textAlign: "center",
      padding: "9px 16px"
    }
  }, "Livraison offerte en France \xB7 Retours sous 30 jours");
}
function Header({
  route,
  go,
  count,
  openCart
}) {
  const m = useMobile();
  const [menu, setMenu] = React.useState(false);
  React.useEffect(() => setMenu(false), [route]);
  return /*#__PURE__*/React.createElement("header", {
    style: {
      position: "sticky",
      top: 0,
      zIndex: 30,
      background: "var(--glass-bg)",
      backdropFilter: "blur(var(--blur-glass))",
      WebkitBackdropFilter: "blur(var(--blur-glass))",
      borderBottom: "1px solid var(--border-1)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: "var(--container-max)",
      margin: "0 auto",
      padding: m ? "0 16px" : "0 32px",
      height: m ? 60 : "var(--header-h)",
      display: "flex",
      alignItems: "center",
      gap: m ? 8 : 40
    }
  }, m && /*#__PURE__*/React.createElement(IconButton, {
    icon: menu ? "x" : "menu",
    label: "Menu",
    onClick: () => setMenu(!menu)
  }), /*#__PURE__*/React.createElement("a", {
    onClick: () => go("/"),
    style: {
      cursor: "pointer",
      textDecoration: "none",
      color: "var(--fg-1)",
      fontFamily: "var(--font-display)",
      fontStretch: "112%",
      fontWeight: 800,
      fontSize: m ? 21 : 24,
      letterSpacing: "-.02em",
      flex: m ? 1 : "none",
      textAlign: m ? "center" : "left"
    }
  }, "OVFLE"), !m && /*#__PURE__*/React.createElement("nav", {
    style: {
      display: "flex",
      gap: 28,
      flex: 1
    }
  }, NAV.map(([l, r]) => /*#__PURE__*/React.createElement("a", {
    key: r,
    onClick: () => go(r),
    style: {
      cursor: "pointer",
      textDecoration: "none",
      fontSize: 15,
      fontWeight: 500,
      color: route === r ? "var(--fg-1)" : "var(--fg-2)"
    }
  }, l))), !m && /*#__PURE__*/React.createElement(Button, {
    size: "sm",
    onClick: () => go("/produit")
  }, "Acheter"), /*#__PURE__*/React.createElement(IconButton, {
    icon: "shopping-bag",
    label: "Panier",
    badge: count || undefined,
    onClick: openCart
  })), m && menu && /*#__PURE__*/React.createElement("nav", {
    style: {
      borderTop: "1px solid var(--border-1)",
      background: "var(--bg-page)",
      padding: "8px 16px 24px",
      display: "flex",
      flexDirection: "column"
    }
  }, NAV.map(([l, r]) => /*#__PURE__*/React.createElement("a", {
    key: r,
    onClick: () => go(r),
    style: {
      cursor: "pointer",
      textDecoration: "none",
      color: "var(--fg-1)",
      fontFamily: "var(--font-display)",
      fontStretch: "112%",
      fontWeight: 700,
      fontSize: 26,
      letterSpacing: "-.02em",
      padding: "14px 0",
      borderBottom: "1px solid var(--border-1)"
    }
  }, l)), /*#__PURE__*/React.createElement(Button, {
    size: "lg",
    fullWidth: true,
    style: {
      marginTop: 20
    },
    onClick: () => go("/produit")
  }, "Acheter le WP-1")));
}
function Footer({
  go
}) {
  const m = useMobile();
  const col = (h, items) => /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: 12,
      letterSpacing: ".1em",
      textTransform: "uppercase",
      color: "var(--ink-400)"
    }
  }, h), items.map(([l, r]) => /*#__PURE__*/React.createElement("a", {
    key: l,
    onClick: r ? () => go(r) : undefined,
    style: {
      fontSize: 15,
      color: "var(--ink-200)",
      textDecoration: "none",
      cursor: r ? "pointer" : "default"
    }
  }, l)));
  return /*#__PURE__*/React.createElement("footer", {
    style: {
      background: "var(--ink-900)",
      color: "var(--paper-0)",
      marginTop: m ? 64 : "var(--space-10)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: "var(--container-max)",
      margin: "0 auto",
      padding: m ? "48px 16px 32px" : "64px 32px 40px",
      display: "grid",
      gridTemplateColumns: m ? "1fr 1fr" : "2fr 1fr 1fr 1fr",
      gap: 32
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 14,
      gridColumn: m ? "1 / -1" : undefined
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-display)",
      fontStretch: "112%",
      fontWeight: 800,
      fontSize: 40,
      letterSpacing: "-.02em"
    }
  }, "OVFLE"), /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--ink-300)",
      fontSize: 15,
      maxWidth: 300
    }
  }, "Le suivi sant\xE9 sans \xE9cran. Mesurez tout, sans regarder votre poignet.")), col("Boutique", [["WP-1", "/produit"], ["Couleurs", "/couleurs"], ["Accessoires", "/accessoires"]]), col("Aide", [["Comment ça marche", "/fonctionnement"], ["Livraison et retours"], ["Garantie 2 ans"], ["Contact"]]), col("Suivre", [["Instagram"], ["YouTube"], ["TikTok"]])), /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: "var(--container-max)",
      margin: "0 auto",
      padding: m ? "18px 16px" : "20px 32px",
      borderTop: "1px solid var(--border-inverse)",
      display: "flex",
      flexWrap: "wrap",
      gap: 16,
      justifyContent: "space-between",
      fontFamily: "var(--font-mono)",
      fontSize: 12,
      color: "var(--ink-400)"
    }
  }, /*#__PURE__*/React.createElement("span", null, "\xA9 2026 OVFLE"), /*#__PURE__*/React.createElement("span", null, "CB \xB7 PayPal \xB7 Apple Pay \xB7 Google Pay")));
}
const Eyebrow = ({
  children,
  inverse,
  style
}) => /*#__PURE__*/React.createElement("div", {
  style: {
    fontFamily: "var(--font-mono)",
    fontSize: 12,
    letterSpacing: ".1em",
    textTransform: "uppercase",
    color: inverse ? "var(--pulse-400)" : "var(--accent)",
    marginBottom: 14,
    ...style
  }
}, children);
function H2({
  children,
  style
}) {
  const m = useMobile();
  return /*#__PURE__*/React.createElement("h2", {
    style: {
      margin: 0,
      fontFamily: "var(--font-display)",
      fontStretch: "112%",
      fontWeight: 700,
      fontSize: m ? 32 : 48,
      lineHeight: 1.05,
      letterSpacing: "-.025em",
      textWrap: "balance",
      ...style
    }
  }, children);
}
function Wrap({
  children,
  style
}) {
  const m = useMobile();
  return /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: "var(--container-max)",
      margin: "0 auto",
      padding: m ? "0 16px" : "0 32px",
      boxSizing: "border-box",
      ...style
    }
  }, children);
}
function Section({
  children,
  style
}) {
  const m = useMobile();
  return /*#__PURE__*/React.createElement(Wrap, {
    style: {
      paddingTop: m ? 64 : 96,
      ...style
    }
  }, children);
}
function Photo({
  color,
  src,
  ratio = "1 / 1",
  radius = "xl",
  label,
  style
}) {
  const c = color || {};
  return /*#__PURE__*/React.createElement(ProductMedia, {
    src: src !== undefined ? src : c.img,
    tone: c.img || src ? "#E9E8E4" : c.tone,
    ratio: ratio,
    radius: radius,
    alt: "WP-1 " + (c.name || ""),
    label: label || "WP-1 · " + (c.name || "") + " · photo à venir",
    style: style
  });
}
function ProductTile({
  p,
  color,
  onAdd,
  go
}) {
  const S = window.SITE;
  return /*#__PURE__*/React.createElement(Card, {
    padding: 0,
    radius: "lg",
    style: {
      overflow: "hidden",
      display: "flex",
      flexDirection: "column"
    }
  }, /*#__PURE__*/React.createElement("div", {
    onClick: go,
    style: {
      cursor: go ? "pointer" : "default"
    }
  }, p.id === "charger" ? /*#__PURE__*/React.createElement(ProductMedia, {
    radius: "xs",
    tone: "var(--paper-50)",
    label: "Chargeur \xB7 photo \xE0 venir",
    ratio: "4 / 3"
  }) : p.id === "pack" ? /*#__PURE__*/React.createElement(ProductMedia, {
    radius: "xs",
    src: "assets/wp1-grid.jpg",
    tone: "#E9E8E4",
    ratio: "4 / 3"
  }) : /*#__PURE__*/React.createElement(Photo, {
    color: color,
    radius: "xs",
    ratio: "4 / 3"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 18,
      display: "flex",
      flexDirection: "column",
      gap: 12,
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 600,
      fontSize: 16
    }
  }, p.name), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14,
      color: "var(--fg-2)"
    }
  }, p.sub)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      marginTop: "auto"
    }
  }, /*#__PURE__*/React.createElement(PriceTag, {
    size: "sm",
    price: p.price,
    compareAt: p.compareAt,
    format: S.eur
  }), /*#__PURE__*/React.createElement(Button, {
    size: "sm",
    variant: "secondary",
    iconLeft: "plus",
    onClick: onAdd
  }, "Ajouter"))));
}
Object.assign(window, {
  useMobile,
  AnnouncementBar,
  Header,
  Footer,
  Eyebrow,
  H2,
  Wrap,
  Section,
  Photo,
  ProductTile
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "site/Layout.jsx", error: String((e && e.message) || e) }); }

// site/Product.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const {
  Button,
  IconButton,
  Badge,
  Tag,
  Card,
  Icon,
  Input,
  Select,
  Radio,
  Checkbox,
  Switch,
  QuantityStepper,
  ColorSwatchPicker,
  Tabs,
  Accordion,
  Dialog,
  Toast,
  MetricStat,
  ProductMedia,
  PriceTag,
  Tooltip
} = window.OVFLEDesignSystem_b73ae2;
function Product({
  initialColor,
  add,
  go
}) {
  const S = window.SITE;
  const m = useMobile();
  const [cw, setCw] = React.useState(initialColor || "black");
  const [q, setQ] = React.useState(1);
  const [tab, setTab] = React.useState("Présentation");
  const [g, setG] = React.useState(0);
  const [extra, setExtra] = React.useState({
    charger: false,
    pack: false
  });
  const c = S.colors.find(x => x.id === cw);
  const p = S.products.wp1;
  const gallery = [{
    color: c
  }, {
    src: "assets/wp1-beige-sand.jpg",
    color: S.colors[1]
  }, {
    src: "assets/wp1-grid.jpg",
    color: {
      name: "collection"
    }
  }];
  React.useEffect(() => setG(0), [cw]);
  const total = p.price * q + (extra.charger ? S.products.charger.price : 0) + (extra.pack ? S.products.pack.price : 0);
  const buy = () => {
    add("wp1", cw, q);
    if (extra.charger) add("charger", null, 1, true);
    if (extra.pack) add("pack", null, 1, true);
  };
  const trust = [["truck", "Livraison offerte, 2 à 4 jours"], ["rotate-ccw", "Retours gratuits sous 30 jours"], ["shield-check", "Garantie 2 ans"]];
  return /*#__PURE__*/React.createElement(Wrap, {
    style: {
      paddingTop: m ? 20 : 40
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: 12,
      color: "var(--fg-2)",
      marginBottom: m ? 16 : 24
    }
  }, /*#__PURE__*/React.createElement("a", {
    onClick: () => go("/"),
    style: {
      cursor: "pointer",
      color: "inherit",
      textDecoration: "none"
    }
  }, "Accueil"), " / WP-1 / ", c.name), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: m ? "1fr" : "minmax(0,1.15fr) minmax(0,1fr)",
      gap: m ? 24 : 56,
      alignItems: "start"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 12,
      position: m ? "static" : "sticky",
      top: 100
    }
  }, /*#__PURE__*/React.createElement(Photo, gallery[g]), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(3,1fr)",
      gap: 10
    }
  }, gallery.map((x, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    onClick: () => setG(i),
    style: {
      cursor: "pointer",
      borderRadius: "var(--radius-md)",
      outline: g === i ? "1.5px solid var(--ink-900)" : "none",
      outlineOffset: 3
    }
  }, /*#__PURE__*/React.createElement(Photo, _extends({}, x, {
    radius: "md",
    label: " "
  })))))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 22
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 8,
      marginBottom: 14
    }
  }, /*#__PURE__*/React.createElement(Badge, {
    tone: "success",
    dot: true
  }, "En stock"), /*#__PURE__*/React.createElement(Badge, {
    tone: "ink"
  }, "\u221220 %")), /*#__PURE__*/React.createElement("h1", {
    style: {
      margin: 0,
      fontFamily: "var(--font-display)",
      fontStretch: "112%",
      fontWeight: 800,
      fontSize: m ? 48 : "clamp(48px,5.5vw,68px)",
      lineHeight: .96,
      letterSpacing: "-.035em"
    }
  }, "WP-1"), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: "10px 0 0",
      color: "var(--fg-2)",
      fontSize: 17
    }
  }, "Bracelet de suivi sans \xE9cran. Suivi sant\xE9 24/7, autonomie de 7 \xE0 10 jours.")), /*#__PURE__*/React.createElement(PriceTag, {
    price: p.price,
    compareAt: p.compareAt,
    size: "lg",
    format: S.eur
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(ColorSwatchPicker, {
    options: S.colors.map(x => ({
      id: x.id,
      name: x.name,
      color: x.tone
    })),
    value: cw,
    onChange: setCw
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      color: "var(--fg-2)",
      marginTop: 8
    }
  }, c.clasp, " \xB7 ", /*#__PURE__*/React.createElement("a", {
    onClick: () => go("/couleurs"),
    style: {
      cursor: "pointer"
    }
  }, "Comparer les couleurs"))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 14,
      fontWeight: 600
    }
  }, "Compl\xE9tez votre commande"), [["charger", "Chargeur de rechange"], ["pack", "Pack 3 bracelets"]].map(([k, l]) => /*#__PURE__*/React.createElement(Card, {
    key: k,
    padding: 14,
    radius: "md",
    style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      gap: 12
    }
  }, /*#__PURE__*/React.createElement(Checkbox, {
    label: l,
    checked: extra[k],
    onChange: v => setExtra({
      ...extra,
      [k]: v
    })
  }), /*#__PURE__*/React.createElement(PriceTag, {
    size: "sm",
    price: S.products[k].price,
    format: v => "+ " + S.eur(v)
  })))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 12
    }
  }, /*#__PURE__*/React.createElement(QuantityStepper, {
    value: q,
    onChange: setQ,
    max: 5
  }), /*#__PURE__*/React.createElement(Button, {
    fullWidth: true,
    iconLeft: "shopping-bag",
    onClick: buy
  }, "Ajouter au panier \xB7 ", S.eur(total))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 10,
      padding: "18px 0",
      borderTop: "1px solid var(--border-1)",
      borderBottom: "1px solid var(--border-1)"
    }
  }, trust.map(([i, t]) => /*#__PURE__*/React.createElement("span", {
    key: t,
    style: {
      display: "flex",
      alignItems: "center",
      gap: 10,
      fontSize: 15
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: i,
    size: 18,
    color: "var(--accent)"
  }), t))), /*#__PURE__*/React.createElement(Tabs, {
    tabs: ["Présentation", "Caractéristiques", "Dans la boîte"],
    value: tab,
    onChange: setTab,
    style: {
      gap: m ? 20 : 28
    }
  }), tab === "Présentation" && /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      color: "var(--fg-2)",
      fontSize: 15,
      lineHeight: 1.6
    }
  }, "Le WP-1 supprime l'\xE9cran pour que vous perdiez l'habitude de le regarder. Il mesure en silence et se synchronise avec l'application quand vous voulez consulter vos donn\xE9es. Le bracelet tress\xE9 \xE9lastique s'enfile sans boucle et se fait oublier, m\xEAme la nuit."), tab === "Caractéristiques" && /*#__PURE__*/React.createElement("div", null, S.specs.map(([k, v]) => /*#__PURE__*/React.createElement("div", {
    key: k,
    style: {
      display: "flex",
      justifyContent: "space-between",
      gap: 16,
      padding: "11px 0",
      borderBottom: "1px solid var(--border-1)",
      fontSize: 15
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--fg-2)"
    }
  }, k), /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 500,
      textAlign: "right"
    }
  }, v)))), tab === "Dans la boîte" && /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexWrap: "wrap",
      gap: 8
    }
  }, S.box.map(t => /*#__PURE__*/React.createElement(Tag, {
    key: t,
    icon: "package"
  }, t))))), /*#__PURE__*/React.createElement(Section, {
    style: {
      padding: 0,
      paddingTop: m ? 64 : 96
    }
  }, /*#__PURE__*/React.createElement(Eyebrow, null, "Fonctionnement"), /*#__PURE__*/React.createElement(H2, {
    style: {
      maxWidth: 620
    }
  }, "Vos donn\xE9es sont dans votre poche, pas sur votre poignet."), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 20
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    iconRight: "arrow-right",
    onClick: () => go("/fonctionnement")
  }, "Voir comment \xE7a marche"))));
}
window.Product = Product;
})(); } catch (e) { __ds_ns.__errors.push({ path: "site/Product.jsx", error: String((e && e.message) || e) }); }

// site/data.js
try { (() => {
const eur = v => Number(v).toLocaleString("fr-FR", {
  style: "currency",
  currency: "EUR"
});
window.SITE = {
  eur,
  colors: [{
    id: "black",
    name: "Noir",
    tone: "var(--band-black)",
    img: "assets/wp1-black-studio.jpg",
    clasp: "Fermoir noir",
    mood: "Le plus discret, au bureau comme à la salle."
  }, {
    id: "beige",
    name: "Beige",
    tone: "var(--band-beige)",
    img: "assets/wp1-beige-sand.jpg",
    clasp: "Fermoir argent",
    mood: "Clair et chaud, se fait oublier sur peau mate."
  }, {
    id: "dark-blue",
    name: "Bleu nuit",
    tone: "var(--band-dark-blue)",
    img: "assets/wp1-dark-blue.jpg",
    clasp: "Fermoir argent",
    mood: "Profond, passe avec le denim."
  }, {
    id: "dark-green",
    name: "Vert olive",
    tone: "var(--band-dark-green)",
    img: "assets/wp1-dark-green.jpg",
    clasp: "Fermoir argent",
    mood: "Sobre, avec une note outdoor."
  }, {
    id: "deep-teal",
    name: "Bleu canard",
    tone: "var(--band-deep-teal)",
    img: "assets/wp1-deep-teal.jpg",
    clasp: "Fermoir argent",
    mood: "Notre couleur signature."
  }, {
    id: "light-gray",
    name: "Gris clair",
    tone: "var(--band-light-gray)",
    img: null,
    clasp: "Fermoir argent",
    mood: "Neutre et lumineux."
  }, {
    id: "light-green",
    name: "Vert clair",
    tone: "var(--band-light-green)",
    img: null,
    clasp: "Fermoir argent",
    mood: "Frais, pensé pour l'été."
  }, {
    id: "clear",
    name: "Transparent",
    tone: "var(--band-clear)",
    img: null,
    clasp: "Fermoir argent",
    mood: "Minimal jusqu'au bout."
  }],
  products: {
    wp1: {
      id: "wp1",
      name: "OVFLE WP-1",
      short: "WP-1",
      sub: "Bracelet de suivi sans écran",
      price: 69,
      compareAt: 89,
      hasColor: true
    },
    strap: {
      id: "strap",
      name: "Bracelet tissé",
      short: "Bracelet tissé",
      sub: "Rechange, 8 couleurs",
      price: 19.9,
      hasColor: true
    },
    pack: {
      id: "pack",
      name: "Pack 3 bracelets",
      short: "Pack 3 bracelets",
      sub: "Noir, Beige, Bleu canard",
      price: 49,
      compareAt: 59.7
    },
    charger: {
      id: "charger",
      name: "Chargeur magnétique",
      short: "Chargeur",
      sub: "USB-C, 1 m",
      price: 14.9
    }
  },
  specs: [["Écran", "Aucun, sans écran"], ["Poids", "25 g"], ["Batterie", "125 mAh, 7 à 10 jours"], ["Capteurs", "Fréquence cardiaque, SpO₂, accéléromètre"], ["Suivi", "Sommeil, pas, distance, calories"], ["Connexion", "Bluetooth, application iOS et Android"], ["Bracelet", "Tissu tressé élastique"]],
  box: ["Bracelet WP-1", "Chargeur magnétique", "Guide de démarrage"],
  faq: [{
    title: "Le WP-1 a-t-il un écran ?",
    content: "Non. Il est sans écran par conception. Tout ce qu'il mesure se synchronise avec l'application sur votre téléphone."
  }, {
    title: "Quelle est l'autonomie ?",
    content: "7 à 10 jours par charge, avec le suivi cardiaque, SpO₂, sommeil et activité actif en continu."
  }, {
    title: "Compatible iPhone et Android ?",
    content: "Oui. Le bracelet se connecte en Bluetooth à l'application compagnon, disponible sur les deux plateformes."
  }, {
    title: "Livraison et retours ?",
    content: "Livraison offerte en France métropolitaine sous 2 à 4 jours ouvrés. Vous avez 30 jours pour changer d'avis."
  }, {
    title: "Puis-je changer de bracelet ?",
    content: "Oui. Le module se détache en quelques secondes : choisissez une autre couleur dans nos accessoires."
  }],
  shipping: [{
    value: "standard",
    label: "Colissimo, 2 à 4 jours",
    description: "Offerte",
    price: 0
  }, {
    value: "express",
    label: "Chronopost, 24 h",
    description: "9,90 €",
    price: 9.9
  }]
};
})(); } catch (e) { __ds_ns.__errors.push({ path: "site/data.js", error: String((e && e.message) || e) }); }

// ui_kits/storefront/CartDrawer.jsx
try { (() => {
const {
  Button,
  IconButton,
  Badge,
  Tag,
  Card,
  Icon,
  Input,
  Select,
  Radio,
  Checkbox,
  QuantityStepper,
  ColorSwatchPicker,
  OVFLE_COLORWAYS,
  Tabs,
  Accordion,
  Dialog,
  Toast,
  MetricStat,
  ProductMedia,
  PriceTag
} = window.OVFLEDesignSystem_b73ae2;
function CartDrawer({
  open,
  items,
  setItems,
  onClose,
  checkout
}) {
  const D = window.OVFLE_DATA;
  const [rm, setRm] = React.useState(null);
  const sub = items.reduce((s, i) => s + i.qty * D.product.price, 0);
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    onClick: onClose,
    style: {
      position: "fixed",
      inset: 0,
      zIndex: 50,
      background: "rgba(14,15,13,.42)",
      opacity: open ? 1 : 0,
      pointerEvents: open ? "auto" : "none",
      transition: "opacity var(--dur-slow) var(--ease-out)"
    }
  }), /*#__PURE__*/React.createElement("aside", {
    style: {
      position: "fixed",
      top: 0,
      right: 0,
      bottom: 0,
      width: 420,
      zIndex: 51,
      background: "var(--bg-page)",
      boxShadow: "var(--shadow-3)",
      transform: open ? "none" : "translateX(100%)",
      transition: "transform var(--dur-slow) var(--ease-out)",
      display: "flex",
      flexDirection: "column"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      padding: "20px 24px",
      borderBottom: "1px solid var(--border-1)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-display)",
      fontStretch: "112%",
      fontWeight: 700,
      fontSize: 22,
      letterSpacing: "-.02em"
    }
  }, "Cart"), /*#__PURE__*/React.createElement(IconButton, {
    icon: "x",
    label: "Close cart",
    onClick: onClose
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      overflow: "auto",
      padding: "8px 24px"
    }
  }, items.length === 0 && /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "64px 0",
      textAlign: "center",
      color: "var(--fg-2)"
    }
  }, "Your cart is empty."), items.map((it, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      display: "grid",
      gridTemplateColumns: "84px 1fr auto",
      gap: 16,
      padding: "16px 0",
      borderBottom: "1px solid var(--border-1)",
      alignItems: "center"
    }
  }, /*#__PURE__*/React.createElement(ProductMedia, {
    tone: it.color.color,
    radius: "md",
    label: " "
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 600
    }
  }, "WP-1"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14,
      color: "var(--fg-2)",
      marginBottom: 10
    }
  }, it.color.name), /*#__PURE__*/React.createElement(QuantityStepper, {
    size: "sm",
    value: it.qty,
    max: 5,
    onChange: n => setItems(items.map((x, j) => j === i ? {
      ...x,
      qty: n
    } : x))
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      alignItems: "flex-end",
      gap: 10
    }
  }, /*#__PURE__*/React.createElement(PriceTag, {
    price: it.qty * D.product.price,
    size: "sm"
  }), /*#__PURE__*/React.createElement(IconButton, {
    icon: "trash-2",
    label: "Remove",
    size: "sm",
    onClick: () => setRm(i)
  }))))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 24,
      borderTop: "1px solid var(--border-1)",
      display: "flex",
      flexDirection: "column",
      gap: 14
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--fg-2)"
    }
  }, "Subtotal"), /*#__PURE__*/React.createElement(PriceTag, {
    price: sub,
    size: "sm"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      fontSize: 14
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--fg-2)"
    }
  }, "Shipping"), /*#__PURE__*/React.createElement("span", null, "Free")), /*#__PURE__*/React.createElement(Button, {
    variant: "accent",
    size: "lg",
    fullWidth: true,
    disabled: !items.length,
    iconRight: "arrow-right",
    onClick: checkout
  }, "Checkout"))), /*#__PURE__*/React.createElement(Dialog, {
    open: rm != null,
    onClose: () => setRm(null),
    title: "Remove from cart?",
    footer: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Button, {
      variant: "ghost",
      onClick: () => setRm(null)
    }, "Keep it"), /*#__PURE__*/React.createElement(Button, {
      onClick: () => {
        setItems(items.filter((_, j) => j !== rm));
        setRm(null);
      }
    }, "Remove"))
  }, "This WP-1 will be removed from your cart."));
}
window.CartDrawer = CartDrawer;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/storefront/CartDrawer.jsx", error: String((e && e.message) || e) }); }

// ui_kits/storefront/CheckoutScreen.jsx
try { (() => {
const {
  Button,
  IconButton,
  Badge,
  Tag,
  Card,
  Icon,
  Input,
  Select,
  Radio,
  Checkbox,
  QuantityStepper,
  ColorSwatchPicker,
  OVFLE_COLORWAYS,
  Tabs,
  Accordion,
  Dialog,
  Toast,
  MetricStat,
  ProductMedia,
  PriceTag
} = window.OVFLEDesignSystem_b73ae2;
function CheckoutScreen({
  items,
  placeOrder
}) {
  const D = window.OVFLE_DATA;
  const [pay, setPay] = React.useState("cod");
  const sub = items.reduce((s, i) => s + i.qty * D.product.price, 0);
  return /*#__PURE__*/React.createElement(Wrap, {
    style: {
      padding: "48px var(--container-pad) 0",
      display: "grid",
      gridTemplateColumns: "1.3fr 1fr",
      gap: 56
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 28
    }
  }, /*#__PURE__*/React.createElement("h1", {
    style: {
      margin: 0,
      fontFamily: "var(--font-display)",
      fontStretch: "112%",
      fontWeight: 800,
      fontSize: "var(--fs-h1)",
      letterSpacing: "-.03em",
      lineHeight: 1
    }
  }, "Checkout"), /*#__PURE__*/React.createElement("section", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 14
    }
  }, /*#__PURE__*/React.createElement(Eyebrow, null, "01 \xB7 Contact"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr",
      gap: 14
    }
  }, /*#__PURE__*/React.createElement(Input, {
    label: "Full name",
    placeholder: "Ayesha Khan"
  }), /*#__PURE__*/React.createElement(Input, {
    label: "Phone",
    prefix: "+92",
    placeholder: "300 1234567"
  })), /*#__PURE__*/React.createElement(Input, {
    label: "Email (optional)",
    type: "email",
    placeholder: "you@example.com"
  })), /*#__PURE__*/React.createElement("section", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 14
    }
  }, /*#__PURE__*/React.createElement(Eyebrow, null, "02 \xB7 Delivery"), /*#__PURE__*/React.createElement(Input, {
    label: "Address",
    placeholder: "House, street, area"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr",
      gap: 14
    }
  }, /*#__PURE__*/React.createElement(Select, {
    label: "City",
    placeholder: "Choose a city",
    options: D.cities
  }), /*#__PURE__*/React.createElement(Input, {
    label: "Postal code",
    placeholder: "75500"
  }))), /*#__PURE__*/React.createElement("section", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 14
    }
  }, /*#__PURE__*/React.createElement(Eyebrow, null, "03 \xB7 Payment"), /*#__PURE__*/React.createElement(Card, {
    padding: 20
  }, /*#__PURE__*/React.createElement(Radio, {
    value: pay,
    onChange: setPay,
    options: [{
      value: "cod",
      label: "Cash on delivery",
      description: "Pay the rider when your band arrives."
    }, {
      value: "card",
      label: "Debit / credit card",
      description: "Visa, Mastercard, UnionPay"
    }]
  })), /*#__PURE__*/React.createElement(Checkbox, {
    label: "Send order updates on WhatsApp",
    defaultChecked: true
  }))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Card, {
    variant: "sunken",
    padding: 28,
    style: {
      position: "sticky",
      top: 100,
      display: "flex",
      flexDirection: "column",
      gap: 16
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-display)",
      fontStretch: "112%",
      fontWeight: 700,
      fontSize: 22,
      letterSpacing: "-.02em"
    }
  }, "Order summary"), items.map((it, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      display: "grid",
      gridTemplateColumns: "56px 1fr auto",
      gap: 14,
      alignItems: "center"
    }
  }, /*#__PURE__*/React.createElement(ProductMedia, {
    tone: it.color.color,
    radius: "sm",
    label: " "
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 600,
      fontSize: 15
    }
  }, "WP-1 \xD7 ", it.qty), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      color: "var(--fg-2)"
    }
  }, it.color.name)), /*#__PURE__*/React.createElement(PriceTag, {
    size: "sm",
    price: it.qty * D.product.price
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      borderTop: "1px solid var(--border-2)",
      paddingTop: 16,
      display: "flex",
      flexDirection: "column",
      gap: 8,
      fontSize: 15
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--fg-2)"
    }
  }, "Subtotal"), /*#__PURE__*/React.createElement("span", null, "Rs ", sub.toLocaleString("en-PK"))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--fg-2)"
    }
  }, "Shipping"), /*#__PURE__*/React.createElement("span", null, "Free")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "baseline",
      marginTop: 6
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 600
    }
  }, "Total"), /*#__PURE__*/React.createElement(PriceTag, {
    price: sub
  }))), /*#__PURE__*/React.createElement(Button, {
    variant: "accent",
    size: "lg",
    fullWidth: true,
    onClick: placeOrder
  }, pay === "cod" ? "Place order — pay on delivery" : "Pay now"))));
}
function ConfirmScreen({
  go
}) {
  return /*#__PURE__*/React.createElement(Wrap, {
    style: {
      padding: "120px var(--container-pad) 40px",
      display: "flex",
      flexDirection: "column",
      alignItems: "flex-start",
      gap: 20,
      maxWidth: 720
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "check-circle-2",
    size: 40,
    color: "var(--success-600)"
  }), /*#__PURE__*/React.createElement(Eyebrow, null, "Order #OV-20418"), /*#__PURE__*/React.createElement("h1", {
    style: {
      margin: 0,
      fontFamily: "var(--font-display)",
      fontStretch: "112%",
      fontWeight: 800,
      fontSize: "var(--fs-display-l)",
      lineHeight: .96,
      letterSpacing: "-.035em"
    }
  }, "Thanks. It's on its way."), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      color: "var(--fg-2)",
      fontSize: 18,
      maxWidth: 520
    }
  }, "We'll confirm by phone and send tracking on WhatsApp. Delivery takes 2\u20134 working days."), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    onClick: () => go("home")
  }, "Back to home"));
}
Object.assign(window, {
  CheckoutScreen,
  ConfirmScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/storefront/CheckoutScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/storefront/Chrome.jsx
try { (() => {
const {
  Button,
  IconButton,
  Badge,
  Tag,
  Card,
  Icon,
  Input,
  Select,
  Radio,
  Checkbox,
  QuantityStepper,
  ColorSwatchPicker,
  OVFLE_COLORWAYS,
  Tabs,
  Accordion,
  Dialog,
  Toast,
  MetricStat,
  ProductMedia,
  PriceTag
} = window.OVFLEDesignSystem_b73ae2;
function AnnouncementBar() {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: "var(--ink-900)",
      color: "var(--paper-0)",
      fontFamily: "var(--font-mono)",
      fontSize: 12,
      letterSpacing: ".08em",
      textTransform: "uppercase",
      textAlign: "center",
      padding: "9px 16px"
    }
  }, "Free nationwide shipping \xB7 Cash on delivery across Pakistan");
}
function Header({
  go,
  cartCount,
  openCart,
  screen
}) {
  const link = (l, s) => /*#__PURE__*/React.createElement("a", {
    key: l,
    onClick: () => go(s),
    style: {
      cursor: "pointer",
      textDecoration: "none",
      color: screen === s ? "var(--fg-1)" : "var(--fg-2)",
      fontSize: 15,
      fontWeight: 500
    }
  }, l);
  return /*#__PURE__*/React.createElement("header", {
    style: {
      position: "sticky",
      top: 0,
      zIndex: 30,
      background: "var(--glass-bg)",
      backdropFilter: "blur(var(--blur-glass))",
      WebkitBackdropFilter: "blur(var(--blur-glass))",
      borderBottom: "1px solid var(--border-1)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: "var(--container-max)",
      margin: "0 auto",
      padding: "0 var(--container-pad)",
      height: "var(--header-h)",
      display: "flex",
      alignItems: "center",
      gap: 40
    }
  }, /*#__PURE__*/React.createElement("a", {
    onClick: () => go("home"),
    style: {
      cursor: "pointer",
      textDecoration: "none",
      color: "var(--fg-1)",
      fontFamily: "var(--font-display)",
      fontStretch: "112%",
      fontWeight: 800,
      fontSize: 24,
      letterSpacing: "-.02em"
    }
  }, "OVFLE"), /*#__PURE__*/React.createElement("nav", {
    style: {
      display: "flex",
      gap: 28,
      flex: 1
    }
  }, link("Shop WP-1", "product"), link("How it works", "home"), link("Support", "home")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 4
    }
  }, /*#__PURE__*/React.createElement(IconButton, {
    icon: "search",
    label: "Search"
  }), /*#__PURE__*/React.createElement(IconButton, {
    icon: "user",
    label: "Account"
  }), /*#__PURE__*/React.createElement(IconButton, {
    icon: "shopping-bag",
    label: "Cart",
    badge: cartCount || undefined,
    onClick: openCart
  }))));
}
function Footer() {
  const col = (h, items) => /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: 12,
      letterSpacing: ".1em",
      textTransform: "uppercase",
      color: "var(--ink-400)"
    }
  }, h), items.map(i => /*#__PURE__*/React.createElement("span", {
    key: i,
    style: {
      fontSize: 15,
      color: "var(--ink-200)"
    }
  }, i)));
  return /*#__PURE__*/React.createElement("footer", {
    style: {
      background: "var(--ink-900)",
      color: "var(--paper-0)",
      marginTop: "var(--space-10)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: "var(--container-max)",
      margin: "0 auto",
      padding: "64px var(--container-pad) 40px",
      display: "grid",
      gridTemplateColumns: "2fr 1fr 1fr 1fr",
      gap: 32
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 14
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-display)",
      fontStretch: "112%",
      fontWeight: 800,
      fontSize: 40,
      letterSpacing: "-.02em"
    }
  }, "OVFLE"), /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--ink-300)",
      fontSize: 15,
      maxWidth: 280
    }
  }, "Screenless wearable technology, made for distraction-free movement.")), col("Shop", ["WP-1", "Colorways", "Straps"]), col("Help", ["Shipping", "Returns", "Warranty", "Contact"]), col("Follow", ["Instagram", "YouTube", "TikTok"])), /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: "var(--container-max)",
      margin: "0 auto",
      padding: "20px var(--container-pad)",
      borderTop: "1px solid var(--border-inverse)",
      fontFamily: "var(--font-mono)",
      fontSize: 12,
      color: "var(--ink-400)"
    }
  }, "\xA9 2026 OVFLE Pakistan"));
}
const Eyebrow = ({
  children,
  inverse
}) => /*#__PURE__*/React.createElement("div", {
  style: {
    fontFamily: "var(--font-mono)",
    fontSize: 12,
    letterSpacing: ".1em",
    textTransform: "uppercase",
    color: inverse ? "var(--pulse-400)" : "var(--accent)",
    marginBottom: 14
  }
}, children);
const H2 = ({
  children,
  style
}) => /*#__PURE__*/React.createElement("h2", {
  style: {
    margin: 0,
    fontFamily: "var(--font-display)",
    fontStretch: "112%",
    fontWeight: 700,
    fontSize: "var(--fs-h1)",
    lineHeight: 1.05,
    letterSpacing: "-.025em",
    textWrap: "balance",
    ...style
  }
}, children);
const Wrap = ({
  children,
  style
}) => /*#__PURE__*/React.createElement("div", {
  style: {
    maxWidth: "var(--container-max)",
    margin: "0 auto",
    padding: "0 var(--container-pad)",
    ...style
  }
}, children);
Object.assign(window, {
  AnnouncementBar,
  Header,
  Footer,
  Eyebrow,
  H2,
  Wrap
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/storefront/Chrome.jsx", error: String((e && e.message) || e) }); }

// ui_kits/storefront/HomeScreen.jsx
try { (() => {
const {
  Button,
  IconButton,
  Badge,
  Tag,
  Card,
  Icon,
  Input,
  Select,
  Radio,
  Checkbox,
  QuantityStepper,
  ColorSwatchPicker,
  OVFLE_COLORWAYS,
  Tabs,
  Accordion,
  Dialog,
  Toast,
  MetricStat,
  ProductMedia,
  PriceTag
} = window.OVFLEDesignSystem_b73ae2;
function HomeScreen({
  go,
  addToCart
}) {
  const D = window.OVFLE_DATA;
  const [cw, setCw] = React.useState("deep-teal");
  const tone = (OVFLE_COLORWAYS.find(c => c.id === cw) || {}).color;
  const feats = [["heart-pulse", "Heart rate, 24/7", "Continuous readings, day and night."], ["droplet", "SpO₂", "Blood-oxygen checks while you sleep."], ["moon", "Sleep stages", "Light, deep and REM, every night."], ["footprints", "Activity", "Steps, distance and calories."]];
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Wrap, {
    style: {
      display: "grid",
      gridTemplateColumns: "1.05fr 1fr",
      gap: 48,
      alignItems: "center",
      padding: "72px var(--container-pad) 88px"
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 8,
      marginBottom: 24
    }
  }, /*#__PURE__*/React.createElement(Badge, {
    tone: "pulse"
  }, "New"), /*#__PURE__*/React.createElement(Badge, {
    tone: "teal"
  }, "Cash on delivery")), /*#__PURE__*/React.createElement("h1", {
    style: {
      margin: 0,
      fontFamily: "var(--font-display)",
      fontStretch: "112%",
      fontWeight: 800,
      fontSize: "var(--fs-display-xl)",
      lineHeight: .94,
      letterSpacing: "-.035em"
    }
  }, "No screen.", /*#__PURE__*/React.createElement("br", null), "No distractions."), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: "var(--fs-body-l)",
      color: "var(--fg-2)",
      maxWidth: 460,
      margin: "24px 0 32px",
      textWrap: "pretty"
    }
  }, "The WP-1 is a 25-gram band that tracks heart rate, SpO\u2082, sleep and activity around the clock \u2014 and sends it all to your phone."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 12,
      alignItems: "center"
    }
  }, /*#__PURE__*/React.createElement(Button, {
    size: "lg",
    iconRight: "arrow-right",
    onClick: () => go("product")
  }, "Shop WP-1"), /*#__PURE__*/React.createElement(PriceTag, {
    price: D.product.price,
    compareAt: D.product.compareAt
  }))), /*#__PURE__*/React.createElement(ProductMedia, {
    src: D.product.img,
    alt: "OVFLE WP-1 in Black",
    ratio: "4 / 5",
    radius: "xl",
    label: "WP-1 \xB7 Black"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      background: "var(--ink-900)"
    }
  }, /*#__PURE__*/React.createElement(Wrap, {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(4,1fr)",
      gap: 24,
      padding: "56px var(--container-pad)"
    }
  }, /*#__PURE__*/React.createElement(MetricStat, {
    inverse: true,
    size: "lg",
    label: "Weight",
    icon: "feather",
    value: "25",
    unit: "g"
  }), /*#__PURE__*/React.createElement(MetricStat, {
    inverse: true,
    size: "lg",
    label: "Battery",
    icon: "battery-full",
    value: "7\u201310",
    unit: "days"
  }), /*#__PURE__*/React.createElement(MetricStat, {
    inverse: true,
    size: "lg",
    label: "Tracking",
    icon: "activity",
    value: "24/7"
  }), /*#__PURE__*/React.createElement(MetricStat, {
    inverse: true,
    size: "lg",
    label: "Colorways",
    icon: "palette",
    value: "8"
  }))), /*#__PURE__*/React.createElement(Wrap, {
    style: {
      padding: "96px var(--container-pad) 0"
    }
  }, /*#__PURE__*/React.createElement(Eyebrow, null, "What it tracks"), /*#__PURE__*/React.createElement(H2, {
    style: {
      maxWidth: 640
    }
  }, "Everything a smartwatch measures. Nothing it shows you."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(4,1fr)",
      gap: 16,
      marginTop: 40
    }
  }, feats.map(([i, t, d]) => /*#__PURE__*/React.createElement(Card, {
    key: t,
    variant: "sunken",
    padding: 24,
    style: {
      minHeight: 200,
      display: "flex",
      flexDirection: "column",
      justifyContent: "space-between"
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: i,
    size: 28,
    color: "var(--accent)"
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-display)",
      fontStretch: "112%",
      fontWeight: 700,
      fontSize: 20,
      letterSpacing: "-.015em"
    }
  }, t), /*#__PURE__*/React.createElement("div", {
    style: {
      color: "var(--fg-2)",
      fontSize: 15,
      marginTop: 6
    }
  }, d)))))), /*#__PURE__*/React.createElement(Wrap, {
    style: {
      padding: "96px var(--container-pad) 0",
      display: "grid",
      gridTemplateColumns: "1fr 1fr",
      gap: 48,
      alignItems: "center"
    }
  }, /*#__PURE__*/React.createElement(ProductMedia, {
    tone: tone,
    ratio: "1 / 1",
    radius: "xl",
    label: "WP-1 · " + (OVFLE_COLORWAYS.find(c => c.id === cw) || {}).name
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Eyebrow, null, "Colorways"), /*#__PURE__*/React.createElement(H2, null, "Eight straps. Pick the one you'll forget you're wearing."), /*#__PURE__*/React.createElement(ColorSwatchPicker, {
    value: cw,
    onChange: setCw,
    size: 36,
    style: {
      margin: "32px 0"
    }
  }), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    iconRight: "arrow-right",
    onClick: () => go("product", cw)
  }, "Shop this color"))), /*#__PURE__*/React.createElement(Wrap, {
    style: {
      padding: "96px var(--container-pad) 0",
      display: "grid",
      gridTemplateColumns: "1fr 1.4fr",
      gap: 48
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Eyebrow, null, "FAQ"), /*#__PURE__*/React.createElement(H2, null, "Questions, answered.")), /*#__PURE__*/React.createElement(Accordion, {
    items: D.faq,
    defaultOpen: 0
  })));
}
window.HomeScreen = HomeScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/storefront/HomeScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/storefront/ProductScreen.jsx
try { (() => {
const {
  Button,
  IconButton,
  Badge,
  Tag,
  Card,
  Icon,
  Input,
  Select,
  Radio,
  Checkbox,
  QuantityStepper,
  ColorSwatchPicker,
  OVFLE_COLORWAYS,
  Tabs,
  Accordion,
  Dialog,
  Toast,
  MetricStat,
  ProductMedia,
  PriceTag
} = window.OVFLEDesignSystem_b73ae2;
function ProductScreen({
  initialColor,
  addToCart
}) {
  const D = window.OVFLE_DATA;
  const [cw, setCw] = React.useState(initialColor || "black");
  const [q, setQ] = React.useState(1);
  const [tab, setTab] = React.useState("Overview");
  const [img, setImg] = React.useState(0);
  const c = OVFLE_COLORWAYS.find(x => x.id === cw) || OVFLE_COLORWAYS[0];
  const views = ["Front", "Side", "Clasp", "On wrist"];
  const specs = [["Display", "None — screenless"], ["Weight", "25 g"], ["Battery", "125 mAh · 7–10 days"], ["Sensors", "Heart rate, SpO₂, accelerometer"], ["Tracking", "Sleep, steps, distance, calories"], ["Connectivity", "Bluetooth · iOS & Android app"]];
  const trust = [["truck", "Free nationwide shipping"], ["banknote", "Cash on delivery"], ["shield-check", "1-year warranty"]];
  return /*#__PURE__*/React.createElement(Wrap, {
    style: {
      padding: "40px var(--container-pad) 0"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: 12,
      color: "var(--fg-2)",
      marginBottom: 24
    }
  }, "Shop / WP-1 / ", c.name), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1.15fr 1fr",
      gap: 56
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 12
    }
  }, /*#__PURE__*/React.createElement(ProductMedia, {
    src: cw === "black" && img === 0 ? D.product.img : undefined,
    tone: c.color,
    ratio: "1 / 1",
    radius: "xl",
    label: "WP-1 · " + c.name + " · " + views[img]
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(4,1fr)",
      gap: 12
    }
  }, views.map((v, i) => /*#__PURE__*/React.createElement("div", {
    key: v,
    onClick: () => setImg(i),
    style: {
      cursor: "pointer",
      borderRadius: "var(--radius-md)",
      outline: img === i ? "1.5px solid var(--ink-900)" : "none",
      outlineOffset: 3
    }
  }, /*#__PURE__*/React.createElement(ProductMedia, {
    tone: c.color,
    radius: "md",
    label: v
  }))))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 24,
      paddingTop: 8
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 8,
      marginBottom: 14
    }
  }, /*#__PURE__*/React.createElement(Badge, {
    tone: "success",
    dot: true
  }, "In stock"), /*#__PURE__*/React.createElement(Badge, {
    tone: "ink"
  }, "Save Rs 2,500")), /*#__PURE__*/React.createElement("h1", {
    style: {
      margin: 0,
      fontFamily: "var(--font-display)",
      fontStretch: "112%",
      fontWeight: 800,
      fontSize: "var(--fs-display-l)",
      lineHeight: .96,
      letterSpacing: "-.035em"
    }
  }, "WP-1"), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: "10px 0 0",
      color: "var(--fg-2)",
      fontSize: 17
    }
  }, "Screenless fitness band. 24/7 health tracking, 7\u201310 day battery.")), /*#__PURE__*/React.createElement(PriceTag, {
    price: D.product.price,
    compareAt: D.product.compareAt,
    size: "lg"
  }), /*#__PURE__*/React.createElement(ColorSwatchPicker, {
    value: cw,
    onChange: setCw
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 12
    }
  }, /*#__PURE__*/React.createElement(QuantityStepper, {
    value: q,
    onChange: setQ,
    max: 5
  }), /*#__PURE__*/React.createElement(Button, {
    size: "md",
    fullWidth: true,
    iconLeft: "shopping-bag",
    onClick: () => addToCart({
      color: c,
      qty: q
    })
  }, "Add to cart")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 10,
      padding: "18px 0",
      borderTop: "1px solid var(--border-1)",
      borderBottom: "1px solid var(--border-1)"
    }
  }, trust.map(([i, t]) => /*#__PURE__*/React.createElement("span", {
    key: t,
    style: {
      display: "flex",
      alignItems: "center",
      gap: 10,
      fontSize: 15
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: i,
    size: 18,
    color: "var(--accent)"
  }), t))), /*#__PURE__*/React.createElement(Tabs, {
    tabs: ["Overview", "Specs", "In the box"],
    value: tab,
    onChange: setTab
  }), tab === "Overview" && /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      color: "var(--fg-2)",
      fontSize: 15,
      lineHeight: 1.6
    }
  }, "The WP-1 drops the screen so you can drop the habit of checking it. It measures quietly in the background and syncs to the app whenever you want to look."), tab === "Specs" && /*#__PURE__*/React.createElement("div", null, specs.map(([k, v]) => /*#__PURE__*/React.createElement("div", {
    key: k,
    style: {
      display: "flex",
      justifyContent: "space-between",
      padding: "10px 0",
      borderBottom: "1px solid var(--border-1)",
      fontSize: 15
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--fg-2)"
    }
  }, k), /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 500
    }
  }, v)))), tab === "In the box" && /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexWrap: "wrap",
      gap: 8
    }
  }, ["WP-1 band", "Magnetic charger", "Quick-start guide"].map(t => /*#__PURE__*/React.createElement(Tag, {
    key: t,
    icon: "package"
  }, t))))));
}
window.ProductScreen = ProductScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/storefront/ProductScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/storefront/data.js
try { (() => {
window.OVFLE_DATA = {
  product: {
    name: "OVFLE WP-1",
    tagline: "Screenless fitness band",
    price: 12499,
    compareAt: 14999,
    img: "https://ovfle.pk/assets/images/ovfle-wp-1-black.jpg"
  },
  faq: [{
    title: "Does the WP-1 have a screen?",
    content: "No. It's screenless by design. Everything it tracks syncs to the companion app on your phone."
  }, {
    title: "How long does the battery last?",
    content: "7–10 days per charge, with heart rate, SpO₂, sleep and activity tracking running 24/7."
  }, {
    title: "Does it work with iPhone and Android?",
    content: "Yes. Pair it over Bluetooth with the companion app on either platform."
  }, {
    title: "Can I pay on delivery?",
    content: "Yes. Cash on delivery is available across Pakistan, and shipping is free nationwide."
  }],
  cities: ["Karachi", "Lahore", "Islamabad", "Rawalpindi", "Faisalabad", "Multan", "Peshawar", "Quetta"]
};
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/storefront/data.js", error: String((e && e.message) || e) }); }

__ds_ns.MetricStat = __ds_scope.MetricStat;

__ds_ns.PriceTag = __ds_scope.PriceTag;

__ds_ns.ProductMedia = __ds_scope.ProductMedia;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.Icon = __ds_scope.Icon;

__ds_ns.IconButton = __ds_scope.IconButton;

__ds_ns.Tag = __ds_scope.Tag;

__ds_ns.Tooltip = __ds_scope.Tooltip;

__ds_ns.Dialog = __ds_scope.Dialog;

__ds_ns.Toast = __ds_scope.Toast;

__ds_ns.Checkbox = __ds_scope.Checkbox;

__ds_ns.OVFLE_COLORWAYS = __ds_scope.OVFLE_COLORWAYS;

__ds_ns.ColorSwatchPicker = __ds_scope.ColorSwatchPicker;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.QuantityStepper = __ds_scope.QuantityStepper;

__ds_ns.Radio = __ds_scope.Radio;

__ds_ns.Select = __ds_scope.Select;

__ds_ns.Switch = __ds_scope.Switch;

__ds_ns.Accordion = __ds_scope.Accordion;

__ds_ns.Tabs = __ds_scope.Tabs;

})();
